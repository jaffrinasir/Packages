# cgdgarch

`cgdgarch` is an R package for sparse univariate ARCH/GARCH modelling by coordinate gradient descent (CGD). It is intended for problems in which the analyst specifies a reasonably generous maximum lag order and lets a penalty determine which ARCH and GARCH lag coefficients remain active.

The package currently supports adaptive LASSO, SCAD, MCP, arctan, Laplace, and composite L1-Gaussian penalties. Repeated variance recursions, Gaussian quasi-likelihood evaluation, score calculations, and diagonal curvature calculations are accelerated with Rcpp.

## What the package is for

`cgdgarch` focuses on a narrower problem than general-purpose GARCH packages: **simultaneous coefficient estimation and sparse lag selection**. It is not intended to replace mature packages such as `rugarch` or `fGarch` for broad distributional families, asymmetric GARCH variants, ARFIMA mean models, or multivariate volatility modelling.

A typical workflow is:

1. choose maximum ARCH/GARCH orders `(q, s)`;
2. choose a penalty family;
3. construct a dyadic or logarithmic lambda grid;
4. fit the lambda path and select lambda by BIC/other information criteria or cross-validation;
5. inspect selected coefficients, conditional variance, residual dependence, and risk forecasts.

## Installation from local source

```r
install.packages("cgdgarch_0.1.14.tar.gz", repos = NULL, type = "source")
library(cgdgarch)
```

Because the package contains C++ code, a working compilation toolchain is required when installing from source.

## Core functions

| Function | Main role |
|---|---|
| `cgd_garch()` / `cgd_arch()` | Fit a penalized or unpenalized ARCH/GARCH model for a fixed lambda. |
| `lambda_grid_cgd()` | Construct data-dependent dyadic or logarithmic lambda grids. |
| `cgd_lambda_ic_path()` | Fit a lambda path and select a model using information criteria. |
| `cv_cgd_garch()` | Select lambda by expanding-window time-series cross-validation. |
| `solution_path()` | Track coefficient estimates across lambda values. |
| `cgd_variance_trace()` | Compare fitted and explicitly filtered conditional variance traces. |
| `cgd_error_dependence()` | Produce ACF/PACF data for squared standardized errors. |
| `cgd_diagnostic_summary()` | Return compact diagnostic checks with cautious interpretation. |
| `cgd_var()` | Produce Gaussian conditional Value-at-Risk forecasts. |
| `cgd_var_backtest()` | Evaluate VaR exception coverage and independence. |
| `cgd_compare_garch()` | Compare a fixed-order unpenalized fit with `rugarch`/`fGarch` when installed. |
| `cgd_shiny_app()` | Launch the bundled interactive dashboard. |

## Penalty families

- **Adaptive LASSO**: weighted L1 sparsity; useful when a preliminary estimator can provide data-dependent weights.
- **SCAD**: nonconvex sparsity penalty with reduced shrinkage for sufficiently large coefficients.
- **MCP**: nonconvex sparsity penalty with linearly decreasing local slope.
- **Arctan**: bounded nonconvex shrinkage with nonzero slope at the origin under the implemented scale parameterization.
- **Laplace**: bounded exponential-type nonconvex shrinkage with nonzero slope at the origin.
- **Composite L1-Gaussian**: combines exact-zero behaviour from L1 with a smooth Gaussian component; when `alpha = 0`, it becomes purely smooth and should be treated as shrinkage rather than exact subset selection.


### Arctan and Laplace transition scales

The arctan and Laplace constructors use the same argument name, `scale`, because it has the same interpretation in both penalties: it controls the coefficient magnitude over which the penalty changes from steep near zero to comparatively flat away from zero.

```r
penalty_arctan(scale = 0.1)
penalty_laplace(scale = 0.5)
```

The implemented normalized shapes are `(2 / pi) * atan(t / scale)` and `1 - exp(-t / scale)`. A smaller `scale` makes either penalty flatten closer to zero; a larger `scale` extends its near-linear region.

## Main workflow

```r
library(cgdgarch)

set.seed(123)
sim <- simulate_garch(
  n = 1000,
  omega = 0.02,
  alpha = c(0.12, 0, 0.06),
  beta = 0.78,
  return_details = TRUE
)
y <- sim$y

pen <- penalty_scad(a = 3.7)

lg <- lambda_grid_cgd(
  y = y,
  q = 3,
  s = 1,
  penalty = pen,
  grid_depth = 10,
  method = "dyadic",
  fit_unpenalized = FALSE
)

ic_path <- cgd_lambda_ic_path(
  y = y,
  q = 3,
  s = 1,
  penalty = pen,
  lambda = lg$lambda,
  max_iter = 200
)

fit <- ic_path$fits[[ic_path$best$index]]
print(fit)

# Information-criterion profile; legend colours match the plotted curves.
plot(ic_path)

# Penalization solution path from the same fitted lambda sequence.
# The vertical line marks the BIC-selected lambda.
plot(ic_path, type = "coefficients", x_axis = "lambda")
```

## Dyadic and logarithmic lambda grids

The dyadic path starts at `lambda_max` and repeatedly halves the value. The implementation can insert midpoints between adjacent dyadic levels, giving a denser path without losing the simple halving structure. This mirrors the shrinkage-grid strategy used in the published adaptive-LASSO CGD work for ARCH/GARCH models.

A logarithmic path instead places a requested number of lambda values evenly on the log scale between `lambda_max` and `lambda_min`. This is useful when smoother coverage over several orders of magnitude is preferred.

```r
lg_d <- lambda_grid_cgd(y, q = 3, s = 1, penalty = pen,
                        grid_depth = 10, method = "dyadic")
lg_l <- lambda_grid_cgd(y, q = 3, s = 1, penalty = pen,
                        nlambda = 50, lambda_min_ratio = 1e-4,
                        method = "log")
```

A standalone coefficient path can also be generated directly with `solution_path()`.

```r
sp <- solution_path(y, q = 3, s = 1, penalty = pen,
                    lambda = lg_l$lambda, max_iter = 200)
plot(sp, x_axis = "lambda", include_intercept = FALSE)
```

## Diagnostics and visualization

```r
plot_variance_trace(fit)

dep <- cgd_error_dependence(fit, lag.max = 24)
plot_error_acf(dep)
plot_error_pacf(dep)

cgd_diagnostic_summary(fit)
```

The standard errors and stability screens printed by the package are **diagnostic approximations**, not exact post-selection inference for a nonconvex penalized GARCH estimator.

## Value-at-Risk

Because the current implementation uses Gaussian quasi-likelihood, `cgd_var()` uses Gaussian conditional quantiles explicitly.

```r
cgd_var(fit, level = c(0.95, 0.99), n.ahead = 5)
```

For a fitted object, `cgd_var_backtest()` can provide an in-sample calibration screen. A genuine backtest should use realized out-of-sample returns and matching one-step-ahead volatility forecasts.

```r
cgd_var_backtest(fit, level = 0.99)
```

## Empirical context against standard GARCH workflows

For a fixed-order, non-penalized task, `cgd_compare_garch()` can compare `cgdgarch` with `rugarch` and `fGarch` when those packages are installed. The comparison reports parameter estimates and conditional-variance agreement. It is an empirical context check, not a claim that the packages have identical likelihood scaling, initialization, or optimizers.

```r
cmp <- cgd_compare_garch(
  sim$y,
  q = 1,
  s = 1,
  true_sigma2 = sim$sigma2
)
cmp
```

A real-data context check can use percentage log returns from the base-R `EuStockMarkets` data without downloading external data:

```r
dax_ret <- 100 * diff(log(EuStockMarkets[, "DAX"]))
cgd_compare_garch(dax_ret, q = 1, s = 1)
```

Exact numerical equality is not expected because packages differ in initialization and optimization. The comparison is intended to reveal whether parameter scales and conditional-variance paths are broadly coherent on the same fixed-order task.

## Bundled Shiny app

```r
cgd_shiny_app()
```

The dashboard exposes the lambda information-criterion path, fitted versus filtered variance, ACF/PACF of squared standardized errors, interpreted diagnostics, and Gaussian conditional VaR output.

## Methodological reference

The adaptive-LASSO CGD foundation for constrained ARCH/GARCH estimation is described in:

> Nasir, M. J. M., Khan, R. N., Nair, G., & Nur, D. (2025). Coordinate gradient descent algorithm in adaptive LASSO for pure ARCH and pure GARCH models. *Computational Statistics*, 40, 3527–3561. https://doi.org/10.1007/s00180-025-01642-1

## Authors and collaborators

- MUHAMMAD JAFFRI MOHD NASIR <jaffri.mn@umk.edu.my>
- Gopalan Nair <gopalan.nair@uwa.edu.au>
- Darfiana Nur <darfiana.nur@uwa.edu.au>
- Ahmad Hakiim Jamaluddin <ahmadhakiim@upm.edu.my>
