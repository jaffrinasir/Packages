#' Simulate an ARCH/GARCH series
#'
#' Simulates a univariate ARCH/GARCH process with user-specified ARCH and GARCH
#' coefficients. By default the function returns only the simulated return series,
#' preserving the simple interface used throughout the package. Set
#' `return_details = TRUE` to also retain the latent conditional variance and
#' innovations, which is useful for simulation benchmarking.
#'
#' @param n Number of observations returned after burn-in.
#' @param omega Positive variance intercept.
#' @param alpha Numeric vector of ARCH coefficients. Use `numeric(0)` for no ARCH terms.
#' @param beta Numeric vector of GARCH coefficients. Use `numeric(0)` for a pure ARCH model.
#' @param innov Innovation generator accepting one integer argument and returning that many draws.
#' @param burnin Number of burn-in observations.
#' @param return_details Logical; if `TRUE`, return the series, latent variance,
#'   innovations, and parameter values in a list.
#' @return A numeric vector when `return_details = FALSE`; otherwise an object of
#'   class `cgd_garch_simulation` containing `y`, `sigma2`, `innovations`, and
#'   `parameters`.
#' @examples
#' set.seed(1)
#' y <- simulate_garch(300, omega = 0.02, alpha = 0.1, beta = 0.8)
#' sim <- simulate_garch(300, omega = 0.02, alpha = 0.1, beta = 0.8,
#'                       return_details = TRUE)
#' head(sim$sigma2)
simulate_garch <- function(n, omega = 0.01, alpha = 0.1, beta = 0.8,
                           innov = stats::rnorm, burnin = 200L,
                           return_details = FALSE) {
  n <- as.integer(n)
  burnin <- as.integer(burnin)
  if (n < 1L) stop("`n` must be positive.")
  if (burnin < 0L) stop("`burnin` must be non-negative.")
  if (!is.numeric(omega) || length(omega) != 1L || !is.finite(omega) || omega <= 0) {
    stop("`omega` must be a positive finite scalar.")
  }
  alpha <- as.numeric(alpha); beta <- as.numeric(beta)
  if (any(!is.finite(alpha)) || any(alpha < 0) || any(!is.finite(beta)) || any(beta < 0)) {
    stop("`alpha` and `beta` must contain non-negative finite values.")
  }
  q <- length(alpha); s <- length(beta); h <- max(q, s, 1L)
  total <- n + burnin + h
  eta <- as.numeric(innov(total))
  if (length(eta) != total || any(!is.finite(eta))) {
    stop("`innov` must return exactly `n + burnin + max(q, s, 1)` finite values.")
  }
  y <- rep(0, total)
  persistence <- sum(alpha) + sum(beta)
  init_var <- omega / max(1 - persistence, 0.05)
  sig <- rep(max(init_var, 1e-12), total)
  for (tt in (h + 1L):total) {
    v <- omega
    if (q > 0L) for (i in seq_len(q)) v <- v + alpha[i] * y[tt - i]^2
    if (s > 0L) for (j in seq_len(s)) v <- v + beta[j] * sig[tt - j]
    sig[tt] <- max(v, 1e-12)
    y[tt] <- eta[tt] * sqrt(sig[tt])
  }
  keep <- (burnin + h + 1L):total
  yy <- y[keep]
  if (!isTRUE(return_details)) return(yy)
  ans <- list(
    y = yy,
    sigma2 = sig[keep],
    innovations = eta[keep],
    parameters = c(omega = omega,
                   if (q > 0L) stats::setNames(alpha, paste0("alpha", seq_len(q))) else numeric(0),
                   if (s > 0L) stats::setNames(beta, paste0("beta", seq_len(s))) else numeric(0)),
    q = q,
    s = s,
    burnin = burnin
  )
  class(ans) <- "cgd_garch_simulation"
  ans
}
