.safe_p <- function(p) {
  p <- suppressWarnings(as.numeric(p))
  if (!length(p) || all(!is.finite(p))) NA_real_ else min(p, na.rm = TRUE)
}

.cgd_stationary_init <- function(par, y) {
  lag_sum <- sum(par[-1L], na.rm = TRUE)
  v <- if (is.finite(lag_sum) && lag_sum < 0.995) par[1L] / max(1 - lag_sum, 1e-8) else stats::var(y)
  if (!is.finite(v) || v <= 0) v <- mean(y^2, na.rm = TRUE)
  if (!is.finite(v) || v <= 0) v <- 1
  v
}

.cgd_filter_sigma2 <- function(y, par, q, s, init = c("unconditional", "sample")) {
  init <- match.arg(init)
  y <- as.numeric(y)
  par <- as.numeric(par)
  n <- length(y)
  h <- max(q, s, 1L)
  e2 <- y^2
  init_v <- if (init == "unconditional") .cgd_stationary_init(par, y) else stats::var(y)
  if (!is.finite(init_v) || init_v <= 0) init_v <- mean(e2, na.rm = TRUE)
  if (!is.finite(init_v) || init_v <= 0) init_v <- 1
  sigma2 <- rep(init_v, n)
  if (n <= h) return(pmax(sigma2, 1e-12))
  for (tt in (h + 1L):n) {
    v <- par[1L]
    if (q > 0L) for (i in seq_len(q)) v <- v + par[1L + i] * e2[tt - i]
    if (s > 0L) for (j in seq_len(s)) v <- v + par[1L + q + j] * sigma2[tt - j]
    sigma2[tt] <- max(v, 1e-12)
  }
  sigma2
}

#' Fitted and filtered conditional variance traces
#'
#' Creates a data frame for comparing the conditional variance stored in a fitted
#' `cgd_garch` object with a forward-filtered variance trace produced from the
#' final parameter vector. The filtered trace can be useful in reports and Shiny
#' dashboards because it separates the fitted object from an explicit filtering
#' recursion.
#'
#' @param object A fitted `cgd_garch` object.
#' @param init Initialisation used by the filtering recursion. `"unconditional"` uses
#'   `omega / (1 - sum(alpha,beta))` when feasible; `"sample"` uses the sample variance.
#' @return A data frame with time index, demeaned return, squared error, fitted
#'   sigma squared, filtered sigma squared, and their difference.
#' @examples
#' set.seed(1)
#' y <- simulate_garch(300)
#' fit <- cgd_garch(y, q = 2, s = 1, lambda = 0.001)
#' vt <- cgd_variance_trace(fit)
#' head(vt)
cgd_variance_trace <- function(object, init = c("unconditional", "sample")) {
  if (!inherits(object, "cgd_garch")) stop("`object` must be a cgd_garch fit.")
  init <- match.arg(init)
  filtered <- .cgd_filter_sigma2(object$y, object$coefficients, object$q, object$s, init = init)
  data.frame(
    time = seq_along(object$y),
    return = object$y,
    error2 = object$y^2,
    fitted_sigma2 = object$sigma2,
    filtered_sigma2 = filtered,
    difference = object$sigma2 - filtered,
    stringsAsFactors = FALSE
  )
}

#' Plot fitted and filtered conditional variances
#'
#' @param x A `cgd_garch` object or a data frame returned by `cgd_variance_trace()`.
#' @param log_scale Logical; plot sigma squared on the log scale.
#' @param ... Additional graphical arguments passed to `matplot()`.
#' @return Invisibly returns the variance trace data frame.
plot_variance_trace <- function(x, log_scale = FALSE, ...) {
  trace <- if (inherits(x, "cgd_garch")) cgd_variance_trace(x) else x
  if (!is.data.frame(trace) || !all(c("time", "fitted_sigma2", "filtered_sigma2") %in% names(trace))) {
    stop("`x` must be a cgd_garch fit or output from cgd_variance_trace().")
  }
  yy <- cbind(fitted = trace$fitted_sigma2, filtered = trace$filtered_sigma2)
  if (isTRUE(log_scale)) yy <- log(pmax(yy, 1e-12))
  graphics::matplot(trace$time, yy, type = "l", lty = c(1, 2), lwd = 1.5,
                    xlab = "Time", ylab = if (log_scale) "log(sigma^2)" else "sigma^2",
                    main = "cgdgarch variance trace: fitted and filtered", ...)
  graphics::legend("topright", legend = c("fitted sigma^2", "filtered sigma^2"),
                   lty = c(1, 2), lwd = 1.5, bty = "n")
  invisible(trace)
}

#' ACF and PACF data for squared standardized errors
#'
#' @param object A fitted `cgd_garch` object.
#' @param lag.max Maximum lag to report.
#' @return An object of class `cgd_error_dependence` containing Shiny-ready ACF and PACF data frames.
cgd_error_dependence <- function(object, lag.max = NULL) {
  if (!inherits(object, "cgd_garch")) stop("`object` must be a cgd_garch fit.")
  idx <- .cgd_effective_index(object)
  e2 <- object$residuals[idx]^2
  e2 <- e2[is.finite(e2)]
  if (is.null(lag.max)) lag.max <- min(30L, max(1L, floor(length(e2) / 4)))
  lag.max <- max(1L, min(as.integer(lag.max), length(e2) - 1L))
  ac <- stats::acf(e2, lag.max = lag.max, plot = FALSE, na.action = stats::na.pass)
  pc <- stats::pacf(e2, lag.max = lag.max, plot = FALSE, na.action = stats::na.pass)
  acf_df <- data.frame(lag = seq_len(length(as.numeric(ac$acf)[-1L])), acf = as.numeric(ac$acf)[-1L])
  pacf_df <- data.frame(lag = seq_along(as.numeric(pc$acf)), pacf = as.numeric(pc$acf))
  ans <- list(acf = acf_df, pacf = pacf_df, lag.max = lag.max, n = length(e2))
  class(ans) <- "cgd_error_dependence"
  ans
}

plot_error_acf <- function(x, lag.max = NULL, ...) {
  dep <- if (inherits(x, "cgd_garch")) cgd_error_dependence(x, lag.max = lag.max) else x
  if (!inherits(dep, "cgd_error_dependence")) stop("`x` must be a cgd_garch fit or cgd_error_dependence object.")
  graphics::plot(dep$acf$lag, dep$acf$acf, type = "h", lwd = 2,
                 xlab = "Lag", ylab = "ACF", main = "ACF of squared standardized errors", ...)
  graphics::abline(h = 0, lty = 1)
  ci <- 1.96 / sqrt(dep$n)
  graphics::abline(h = c(-ci, ci), lty = 2)
  invisible(dep)
}

plot_error_pacf <- function(x, lag.max = NULL, ...) {
  dep <- if (inherits(x, "cgd_garch")) cgd_error_dependence(x, lag.max = lag.max) else x
  if (!inherits(dep, "cgd_error_dependence")) stop("`x` must be a cgd_garch fit or cgd_error_dependence object.")
  graphics::plot(dep$pacf$lag, dep$pacf$pacf, type = "h", lwd = 2,
                 xlab = "Lag", ylab = "PACF", main = "PACF of squared standardized errors", ...)
  graphics::abline(h = 0, lty = 1)
  ci <- 1.96 / sqrt(dep$n)
  graphics::abline(h = c(-ci, ci), lty = 2)
  invisible(dep)
}

#' Lambda path with information criteria
#'
#' Fits a model along a lambda grid and records information criteria. This is
#' intended for tuning reports and Shiny dashboards where users need to see how
#' the active set and BIC change as the penalty is relaxed.
#'
#' @param y Numeric return series.
#' @param q Maximum ARCH order.
#' @param s Maximum GARCH order.
#' @param penalty Penalty object.
#' @param lambda Optional lambda vector. If `NULL`, `lambda_grid_cgd()` is used.
#' @param lambda_min_ratio,nlambda,grid_depth,lambda_method Grid arguments passed to `lambda_grid_cgd()`.
#' @param fit_unpenalized Logical; passed to `lambda_grid_cgd()` when `lambda` is `NULL`.
#' @param warm_start Logical; reuse the previous lambda solution as the next start.
#' @param ... Additional arguments passed to `cgd_garch()`.
#' @return An object of class `cgd_ic_path`.
cgd_lambda_ic_path <- function(y, q = 1L, s = 1L, penalty = penalty_scad(),
                               lambda = NULL, lambda_min_ratio = 1e-4,
                               nlambda = 30L, grid_depth = NULL,
                               lambda_method = c("dyadic", "log"),
                               fit_unpenalized = TRUE,
                               warm_start = TRUE, ...) {
  y <- validate_series(y)
  lambda_grid <- NULL
  if (is.null(lambda)) {
    lambda_grid <- lambda_grid_cgd(y, q = q, s = s, penalty = penalty,
                                   lambda_min_ratio = lambda_min_ratio,
                                   nlambda = nlambda, grid_depth = grid_depth,
                                   method = match.arg(lambda_method),
                                   fit_unpenalized = fit_unpenalized, ...)
    lambda <- lambda_grid$lambda
  }
  lambda <- sort(unique(as.numeric(lambda)), decreasing = TRUE)
  fits <- vector("list", length(lambda))
  rows <- vector("list", length(lambda))
  start <- NULL
  for (i in seq_along(lambda)) {
    fits[[i]] <- cgd_garch(y = y, q = q, s = s, penalty = penalty,
                           lambda = lambda[i], start = start, ...)
    if (isTRUE(warm_start)) start <- coef(fits[[i]])
    ic <- .cgd_info_criteria(fits[[i]])
    rows[[i]] <- data.frame(
      index = i,
      lambda = lambda[i],
      log_lambda = log(lambda[i]),
      active_lags = sum(coef(fits[[i]])[-1L] != 0),
      loglik = fits[[i]]$loglik,
      objective = fits[[i]]$objective,
      AIC = unname(ic["Akaike"]),
      BIC = unname(ic["Bayes"]),
      Shibata = unname(ic["Shibata"]),
      Hannan_Quinn = unname(ic["Hannan-Quinn"]),
      converged = fits[[i]]$convergence$converged,
      stringsAsFactors = FALSE
    )
  }
  path <- do.call(rbind, rows)
  coefficients <- do.call(rbind, lapply(fits, coef))
  rownames(coefficients) <- paste0("lambda=", signif(lambda, 3))
  best <- path[which.min(path$BIC), , drop = FALSE]
  ans <- list(path = path, fits = fits, coefficients = coefficients,
              best = best, q = q, s = s,
              penalty = penalty, lambda_grid = lambda_grid)
  class(ans) <- "cgd_ic_path"
  ans
}

print.cgd_ic_path <- function(x, ...) {
  cat("cgdgarch lambda-IC path\n")
  cat("lambda values:", nrow(x$path), " | BIC-selected lambda:", signif(x$best$lambda, 6),
      " | active lags:", x$best$active_lags, "\n")
  print(utils::head(x$path, 10L), row.names = FALSE)
  invisible(x)
}

plot.cgd_ic_path <- function(x,
                             criteria = c("AIC", "BIC", "Hannan_Quinn"),
                             type = c("criteria", "coefficients"),
                             x_axis = c("log_lambda", "lambda"),
                             include_intercept = FALSE,
                             col = NULL, lty = NULL, lwd = 1.6,
                             legend_pos = "topright", legend = TRUE, ...) {
  type <- match.arg(type)
  x_axis <- match.arg(x_axis)

  if (type == "coefficients") {
    co <- x$coefficients
    if (is.null(co)) {
      co <- do.call(rbind, lapply(x$fits, coef))
    }
    .cgd_plot_coefficient_path(
      lambda = x$path$lambda,
      coefficients = co,
      x_axis = x_axis,
      include_intercept = include_intercept,
      selected_lambda = x$best$lambda,
      selected_label = "BIC-selected lambda",
      col = col, lty = lty, lwd = lwd,
      legend_pos = legend_pos, legend = legend,
      main = "Coefficient path with BIC-selected lambda",
      ...
    )
    return(invisible(x))
  }

  criteria <- intersect(criteria, names(x$path))
  if (!length(criteria)) stop("No valid criteria selected.")
  yy <- as.matrix(x$path[, criteria, drop = FALSE])

  if (x_axis == "log_lambda") {
    if (any(!is.finite(x$path$lambda) | x$path$lambda <= 0)) {
      stop("`x_axis = \"log_lambda\"` requires strictly positive lambda values; use `x_axis = \"lambda\"` when the path contains lambda = 0.")
    }
    xx <- x$path$log_lambda
    x_best <- x$best$log_lambda
    xlab <- "log(lambda)"
  } else {
    xx <- x$path$lambda
    x_best <- x$best$lambda
    xlab <- "lambda"
  }

  default_col <- c(
    AIC = "#000000",
    BIC = "#D55E00",
    Shibata = "#0072B2",
    Hannan_Quinn = "#009E73"
  )
  if (is.null(col)) {
    col <- unname(default_col[criteria])
    missing_col <- is.na(col)
    if (any(missing_col)) {
      col[missing_col] <- grDevices::hcl.colors(sum(missing_col), palette = "Dark 3")
    }
  }
  col <- rep(col, length.out = length(criteria))
  if (is.null(lty)) lty <- seq_along(criteria)
  lty <- rep(lty, length.out = length(criteria))
  lwd <- rep(lwd, length.out = length(criteria))

  graphics::matplot(
    xx, yy, type = "l", col = col, lty = lty, lwd = lwd,
    xlab = xlab, ylab = "information criterion per observation",
    main = "Lambda path: IC profile with BIC choice", ...
  )
  graphics::abline(v = x_best, col = "grey30", lty = 3, lwd = 1.1)

  if (isTRUE(legend)) {
    pretty_names <- gsub("_", "-", criteria, fixed = TRUE)
    graphics::legend(
      legend_pos,
      legend = c(pretty_names, "BIC-selected lambda"),
      col = c(col, "grey30"),
      lty = c(lty, 3),
      lwd = c(lwd, 1.1),
      bty = "n"
    )
  }
  invisible(x)
}

#' Diagnostic summary with plain-language interpretation
#'
#' @param object A fitted `cgd_garch` object.
#' @param alpha P-value threshold used for the rule-of-thumb interpretation.
#' @return A data frame of diagnostics and interpretations.
cgd_diagnostic_summary <- function(object, alpha = 0.05) {
  if (!inherits(object, "cgd_garch")) stop("`object` must be a cgd_garch fit.")
  dg <- .cgd_diagnostics(object)
  p_res <- .safe_p(dg$ljung_resid[, "p-value"])
  p_sq <- .safe_p(dg$ljung_sq[, "p-value"])
  p_arch <- .safe_p(dg$arch_lm[, "P-Value"])
  p_sign <- if (!is.null(dg$sign_bias)) .safe_p(dg$sign_bias[, "prob"]) else NA_real_
  p_gof <- .safe_p(dg$pearson[, "p-value(g-1)"])
  ans <- data.frame(
    diagnostic = c("Residual serial correlation", "Squared-error dependence",
                   "ARCH echo regression", "Directional sign/size asymmetry",
                   "Normal-bin calibration", "Score-path drift screen"),
    statistic = c(NA_real_, NA_real_, NA_real_, NA_real_, NA_real_, dg$nyblom$joint),
    p_value = c(p_res, p_sq, p_arch, p_sign, p_gof, NA_real_),
    interpretation = c(
      ifelse(is.finite(p_res) && p_res < alpha, "Serial structure remains in standardized errors.", "No strong residual serial-correlation signal."),
      ifelse(is.finite(p_sq) && p_sq < alpha, "Volatility dependence may remain after filtering.", "No strong squared-error dependence signal."),
      ifelse(is.finite(p_arch) && p_arch < alpha, "ARCH-type remnants remain; consider larger q/s or a different penalty.", "ARCH-remnant regression is not alarming."),
      ifelse(is.finite(p_sign) && p_sign < alpha, "Negative/positive shocks may affect variance asymmetrically.", "No strong sign-bias signal."),
      ifelse(is.finite(p_gof) && p_gof < alpha, "Normal innovation shape is questionable; heavy-tail likelihood may be needed.", "Normal-bin calibration is acceptable at this threshold."),
      "Descriptive stability screen only; compare across fitted specifications."
    ),
    stringsAsFactors = FALSE
  )
  class(ans) <- c("cgd_diagnostic_summary", "data.frame")
  ans
}

print.cgd_diagnostic_summary <- function(x, ..., digits = 4) {
  cat("cgdgarch diagnostic summary\n")
  out <- as.data.frame(x, stringsAsFactors = FALSE)
  print.data.frame(
    out,
    row.names = FALSE,
    right = FALSE,
    digits = digits,
    ...
  )
  invisible(x)
}

#' Launch the bundled cgdgarch Shiny dashboard
#'
#' The dashboard exposes the package workflow through interactive controls and
#' displays the lambda IC path, fitted versus filtered sigma squared, ACF/PACF of
#' squared standardized errors, and interpreted diagnostics.
#'
#' @param ... Additional arguments passed to `shiny::runApp()`.
#' @return The result of `shiny::runApp()`.
cgd_shiny_app <- function(...) {
  if (!requireNamespace("shiny", quietly = TRUE)) {
    stop("The Shiny dashboard requires the 'shiny' package. Install it with install.packages('shiny').", call. = FALSE)
  }
  app_dir <- system.file("shiny", "cgdgarch-dashboard", package = "cgdgarch")
  if (!nzchar(app_dir)) stop("Bundled Shiny app directory not found.", call. = FALSE)
  shiny::runApp(app_dir, ...)
}
