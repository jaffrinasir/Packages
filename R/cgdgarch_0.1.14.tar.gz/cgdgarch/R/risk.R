# Gaussian Value-at-Risk helpers ---------------------------------------------

#' Value-at-Risk from a fitted cgdgarch model
#'
#' Computes one- or multi-step Gaussian conditional Value-at-Risk (VaR) from a
#' fitted `cgd_garch` object. The current package fits a Gaussian quasi-likelihood,
#' so the function deliberately uses the standard normal conditional quantile.
#' It does not silently assume Student-t or skewed innovations.
#'
#' For confidence level `c`, the lower-tail return quantile is
#' `mu + qnorm(1 - c) * sigma`. For a long position with current value `V`, the
#' corresponding loss VaR is `-V` times that return quantile.
#'
#' @param object A fitted `cgd_garch` object.
#' @param level Confidence level(s), typically `0.95` or `0.99`.
#' @param n.ahead Forecast horizon passed to `predict.cgd_garch()`.
#' @param portfolio_value Positive current portfolio value. Use `1` for VaR in return units.
#' @param include_mean Logical; include the fitted constant mean in the quantile.
#' @param positive Logical; if `TRUE`, truncate loss VaR below at zero.
#' @return An object of class `cgd_var`, represented as a data frame with horizon,
#'   confidence level, tail probability, conditional mean and volatility, return
#'   quantile, and loss VaR.
#' @examples
#' set.seed(10)
#' y <- simulate_garch(400, omega = 0.02, alpha = 0.1, beta = 0.8)
#' fit <- cgd_garch(y, q = 1, s = 1, lambda = 0, max_iter = 50)
#' cgd_var(fit, level = c(0.95, 0.99), n.ahead = 3)
cgd_var <- function(object, level = c(0.95, 0.99), n.ahead = 1L,
                    portfolio_value = 1, include_mean = TRUE,
                    positive = TRUE) {
  if (!inherits(object, "cgd_garch")) stop("`object` must be a cgd_garch fit.")
  level <- as.numeric(level)
  if (!length(level) || any(!is.finite(level) | level <= 0.5 | level >= 1)) {
    stop("`level` must contain values strictly between 0.5 and 1.")
  }
  n.ahead <- as.integer(n.ahead)
  if (n.ahead < 1L) stop("`n.ahead` must be positive.")
  if (!is.numeric(portfolio_value) || length(portfolio_value) != 1L ||
      !is.finite(portfolio_value) || portfolio_value <= 0) {
    stop("`portfolio_value` must be a positive finite scalar.")
  }
  fc <- predict(object, n.ahead = n.ahead)
  mu <- if (isTRUE(include_mean)) object$mu else 0
  grid <- expand.grid(h = fc$h, level = level, KEEP.OUT.ATTRS = FALSE,
                      stringsAsFactors = FALSE)
  grid <- grid[order(grid$h, grid$level), , drop = FALSE]
  sig <- fc$sigma_forecast[match(grid$h, fc$h)]
  tail_prob <- 1 - grid$level
  rq <- mu + stats::qnorm(tail_prob) * sig
  loss <- -portfolio_value * rq
  if (isTRUE(positive)) loss <- pmax(loss, 0)
  ans <- data.frame(
    h = grid$h,
    level = grid$level,
    tail_probability = tail_prob,
    mean_forecast = rep(mu, nrow(grid)),
    sigma_forecast = sig,
    return_quantile = rq,
    VaR_loss = loss,
    portfolio_value = rep(portfolio_value, nrow(grid)),
    stringsAsFactors = FALSE
  )
  class(ans) <- c("cgd_var", "data.frame")
  attr(ans, "distribution") <- "Gaussian conditional quantile"
  ans
}

print.cgd_var <- function(x, ...) {
  cat("cgdgarch conditional VaR forecast\n")
  cat("distribution: ", attr(x, "distribution"), "\n", sep = "")
  print.data.frame(x, row.names = FALSE, digits = 6)
  invisible(x)
}

.cgd_xlog <- function(count, prob) {
  if (count == 0) return(0)
  if (!is.finite(prob) || prob <= 0) return(-Inf)
  count * log(prob)
}

.cgd_binom_ll <- function(success, total, prob) {
  failure <- total - success
  .cgd_xlog(success, prob) + .cgd_xlog(failure, 1 - prob)
}

.cgd_markov_ll <- function(n00, n01, n10, n11, p01, p11) {
  .cgd_xlog(n00, 1 - p01) + .cgd_xlog(n01, p01) +
    .cgd_xlog(n10, 1 - p11) + .cgd_xlog(n11, p11)
}

#' Backtest Gaussian conditional Value-at-Risk
#'
#' Provides unconditional-coverage and independence diagnostics for a lower-tail
#' VaR sequence. With only `object` supplied, the function evaluates the fitted
#' in-sample conditional quantiles and labels the result as an in-sample diagnostic.
#' For a genuine out-of-sample backtest, supply both `realized` returns and the
#' matching one-step-ahead `sigma` forecasts.
#'
#' @param object Optional fitted `cgd_garch` object.
#' @param level Confidence level, e.g. `0.95` or `0.99`.
#' @param realized Optional realized out-of-sample return vector.
#' @param sigma Optional conditional standard-deviation forecasts matching `realized`.
#' @param mu Optional conditional mean forecasts. A scalar is recycled. If omitted,
#'   the fitted mean from `object` is used when available, otherwise zero.
#' @return An object of class `cgd_var_backtest` containing exception indicators,
#'   exception rate, Kupiec unconditional-coverage statistic, Christoffersen
#'   independence statistic, and conditional-coverage statistic.
cgd_var_backtest <- function(object = NULL, level = 0.99,
                             realized = NULL, sigma = NULL, mu = NULL) {
  level <- as.numeric(level)[1L]
  if (!is.finite(level) || level <= 0.5 || level >= 1) {
    stop("`level` must be strictly between 0.5 and 1.")
  }
  mode <- "out-of-sample"
  if (is.null(realized) && is.null(sigma)) {
    if (!inherits(object, "cgd_garch")) {
      stop("Supply a fitted `object`, or both `realized` and `sigma`.")
    }
    idx <- .cgd_effective_index(object)
    realized <- object$y_original[idx]
    sigma <- sqrt(pmax(object$sigma2[idx], 1e-12))
    if (is.null(mu)) mu <- object$mu
    mode <- "in-sample diagnostic"
  } else if (is.null(realized) || is.null(sigma)) {
    stop("For an out-of-sample backtest, supply both `realized` and `sigma`.")
  }
  realized <- as.numeric(realized)
  sigma <- as.numeric(sigma)
  if (length(realized) != length(sigma) || length(realized) < 5L) {
    stop("`realized` and `sigma` must have the same length of at least 5.")
  }
  if (is.null(mu)) mu <- if (inherits(object, "cgd_garch")) object$mu else 0
  mu <- as.numeric(mu)
  if (length(mu) == 1L) mu <- rep(mu, length(realized))
  if (length(mu) != length(realized)) stop("`mu` must be a scalar or match `realized`.")
  ok <- is.finite(realized) & is.finite(sigma) & sigma > 0 & is.finite(mu)
  realized <- realized[ok]; sigma <- sigma[ok]; mu <- mu[ok]
  if (length(realized) < 5L) stop("Too few finite observations remain after filtering.")

  p <- 1 - level
  threshold <- mu + stats::qnorm(p) * sigma
  hit <- as.integer(realized < threshold)
  n <- length(hit); x <- sum(hit); phat <- x / n
  ll0 <- .cgd_binom_ll(x, n, p)
  ll1 <- .cgd_binom_ll(x, n, phat)
  lr_uc <- if (is.finite(ll0) && is.finite(ll1)) max(0, -2 * (ll0 - ll1)) else NA_real_

  prev <- head(hit, -1L); curr <- tail(hit, -1L)
  n00 <- sum(prev == 0 & curr == 0); n01 <- sum(prev == 0 & curr == 1)
  n10 <- sum(prev == 1 & curr == 0); n11 <- sum(prev == 1 & curr == 1)
  p01 <- if ((n00 + n01) > 0) n01 / (n00 + n01) else 0
  p11 <- if ((n10 + n11) > 0) n11 / (n10 + n11) else 0
  pall <- (n01 + n11) / max(n00 + n01 + n10 + n11, 1)
  ll_ind0 <- .cgd_markov_ll(n00, n01, n10, n11, pall, pall)
  ll_ind1 <- .cgd_markov_ll(n00, n01, n10, n11, p01, p11)
  lr_ind <- if (is.finite(ll_ind0) && is.finite(ll_ind1)) max(0, -2 * (ll_ind0 - ll_ind1)) else NA_real_
  lr_cc <- if (is.finite(lr_uc) && is.finite(lr_ind)) lr_uc + lr_ind else NA_real_

  tests <- data.frame(
    test = c("Kupiec unconditional coverage", "Christoffersen independence", "Conditional coverage"),
    statistic = c(lr_uc, lr_ind, lr_cc),
    df = c(1L, 1L, 2L),
    p_value = c(if (is.finite(lr_uc)) stats::pchisq(lr_uc, 1, lower.tail = FALSE) else NA_real_,
                if (is.finite(lr_ind)) stats::pchisq(lr_ind, 1, lower.tail = FALSE) else NA_real_,
                if (is.finite(lr_cc)) stats::pchisq(lr_cc, 2, lower.tail = FALSE) else NA_real_),
    stringsAsFactors = FALSE
  )
  series <- data.frame(realized = realized, sigma = sigma, mu = mu,
                       VaR_return_threshold = threshold, exception = hit)
  ans <- list(level = level, tail_probability = p, mode = mode, n = n,
              exceptions = x, exception_rate = phat, expected_rate = p,
              tests = tests, transitions = c(n00 = n00, n01 = n01, n10 = n10, n11 = n11),
              series = series)
  class(ans) <- "cgd_var_backtest"
  ans
}

print.cgd_var_backtest <- function(x, ...) {
  cat("cgdgarch VaR calibration check\n")
  cat("mode: ", x$mode, " | level: ", format(x$level),
      " | exceptions: ", x$exceptions, "/", x$n,
      " | observed rate: ", signif(x$exception_rate, 5),
      " | expected rate: ", signif(x$expected_rate, 5), "\n", sep = "")
  print(x$tests, row.names = FALSE, digits = 6)
  invisible(x)
}


#' Plot a cgdgarch VaR calibration sequence
#'
#' Displays realized returns, the conditional VaR return threshold, and observed
#' exceptions. The plot is especially useful with genuine out-of-sample one-step
#' forecasts supplied to `cgd_var_backtest()`.
#'
#' @param x A `cgd_var_backtest` object.
#' @param ... Graphical arguments passed to the base plotting function.
#' @return Invisibly returns `x`.
plot.cgd_var_backtest <- function(x, ...) {
  if (!inherits(x, "cgd_var_backtest")) stop("`x` must be a cgd_var_backtest object.")
  d <- x$series
  tt <- seq_len(nrow(d))
  ylim <- range(c(d$realized, d$VaR_return_threshold), finite = TRUE)
  graphics::plot(tt, d$realized, type = "l", xlab = "Observation",
                 ylab = "Return / VaR threshold", ylim = ylim, ...)
  graphics::lines(tt, d$VaR_return_threshold, lty = 2, lwd = 2)
  hit <- which(d$exception == 1L)
  if (length(hit)) graphics::points(hit, d$realized[hit], pch = 19)
  graphics::legend("bottomleft",
                   legend = c("Realized return", "VaR return threshold", "Exception"),
                   lty = c(1, 2, NA), pch = c(NA, NA, 19), bty = "n")
  invisible(x)
}
