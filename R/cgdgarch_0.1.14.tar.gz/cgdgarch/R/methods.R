.cgd_rule <- function(width = 76L, char = "-") {
  cat(paste(rep(char, width), collapse = ""), "\n", sep = "")
}

.cgd_section <- function(title) {
  cat("\n:: ", title, "\n", sep = "")
  .cgd_rule(char = "-")
}

.cgd_subsection <- function(title) {
  cat("\n   > ", title, "\n", sep = "")
}

.cgd_header_line <- function(text = "") {
  if (!nzchar(text)) {
    .cgd_rule(char = "=")
  } else {
    cat("\n", text, "\n", sep = "")
    .cgd_rule(char = "=")
  }
}

.cgd_model_label <- function(x) {
  if (x$s > 0L) paste0("GARCH(order = ", x$q, ", ", x$s, ")") else paste0("ARCH(order = ", x$q, ")")
}

.cgd_penalty_label <- function(penalty) {
  nm <- penalty$name
  switch(nm,
         alasso = "adaptive LASSO",
         scad = "SCAD",
         mcp = "MCP",
         arctan = "arctan",
         laplace = "Laplace",
         clg = "composite L1-Gaussian",
         nm)
}

.cgd_effective_index <- function(object) {
  h <- max(object$q, object$s, 1L)
  seq.int(h + 1L, length(object$y))
}

.cgd_derivative_matrix <- function(y, sigma2, par, q, s) {
  n <- length(y)
  h <- max(q, s, 1L)
  p <- length(par)
  err2pad <- c(rep(0, h), y^2)
  sigpad <- c(rep(0, h), sigma2)
  Dpad <- matrix(0, nrow = n + h, ncol = p)

  for (tt in seq_len(n)) {
    row <- tt + h
    Dpad[row, 1L] <- 1
    if (q > 0L) {
      for (i in seq_len(q)) Dpad[row, 1L + i] <- err2pad[row - i]
    }
    if (s > 0L) {
      for (j in seq_len(s)) Dpad[row, 1L + q + j] <- sigpad[row - j]
      for (j in seq_len(s)) Dpad[row, ] <- Dpad[row, ] + par[1L + q + j] * Dpad[row - j, ]
    }
  }

  Dpad[(h + 1L):(n + h), , drop = FALSE]
}

.cgd_score_contributions <- function(object) {
  idx <- .cgd_effective_index(object)
  y <- object$y
  sig <- pmax(object$sigma2, 1e-12)
  par <- object$coefficients
  D <- .cgd_derivative_matrix(y, sig, par, object$q, object$s)[idx, , drop = FALSE]
  e2 <- y[idx]^2
  h <- sig[idx]
  Gvar <- 0.5 * ((1 / h) - (e2 / h^2)) * D
  colnames(Gvar) <- names(par)

  y0 <- object$y_original
  mu <- object$mu
  sig_mu <- stats::var(y0)
  if (!is.finite(sig_mu) || sig_mu <= 0) sig_mu <- 1
  Gmu_full <- (y0 - mu) / sig_mu
  Gmu <- Gmu_full[idx]
  cbind(mu = Gmu, Gvar)
}

.cgd_parameter_tables <- function(object) {
  est <- c(mu = object$mu, object$coefficients)
  idx <- .cgd_effective_index(object)
  n_eff <- length(idx)
  y <- object$y
  sig <- pmax(object$sigma2, 1e-12)
  par <- object$coefficients
  D <- .cgd_derivative_matrix(y, sig, par, object$q, object$s)[idx, , drop = FALSE]
  h <- sig[idx]

  qdiag <- colMeans((D^2) / (h^2))
  se_var <- sqrt(2 / pmax(n_eff * qdiag, .Machine$double.eps))
  names(se_var) <- names(par)

  se_mu <- stats::sd(object$y_original) / sqrt(length(object$y_original))
  if (!is.finite(se_mu)) se_mu <- NA_real_
  se <- c(mu = se_mu, se_var)

  G <- .cgd_score_contributions(object)
  Hdiag_var <- 0.5 * qdiag
  Jdiag_var <- colMeans(G[, names(par), drop = FALSE]^2)
  robust_var <- sqrt(Jdiag_var / pmax(n_eff * Hdiag_var^2, .Machine$double.eps))
  names(robust_var) <- names(par)
  robust_mu <- stats::sd(object$y_original - object$mu) / sqrt(length(object$y_original))
  robust <- c(mu = robust_mu, robust_var)

  make_tab <- function(se_use) {
    tval <- est / se_use
    pval <- 2 * stats::pnorm(abs(tval), lower.tail = FALSE)
    out <- cbind(Estimate = est, `Std. Error` = se_use,
                 `t value` = tval, `Pr(>|t|)` = pval)
    rownames(out) <- names(est)
    out
  }

  list(standard = make_tab(se), robust = make_tab(robust))
}

.cgd_info_criteria <- function(object) {
  n <- object$n_eff
  k <- object$npars
  ll <- object$loglik
  c(Akaike = (-2 * ll + 2 * k) / n,
    Bayes = (-2 * ll + log(n) * k) / n,
    Shibata = (-2 * ll) / n + log((n + 2 * k) / n),
    `Hannan-Quinn` = (-2 * ll + 2 * log(log(n)) * k) / n)
}

.cgd_ljung_box <- function(z, lags, fitdf = 0L) {
  z <- z[is.finite(z)]
  lags <- unique(pmax(1L, pmin(as.integer(lags), length(z) - 1L)))
  out <- matrix(NA_real_, nrow = length(lags), ncol = 2L)
  colnames(out) <- c("statistic", "p-value")
  for (i in seq_along(lags)) {
    bt <- try(stats::Box.test(z, lag = lags[i], type = "Ljung-Box", fitdf = fitdf), silent = TRUE)
    if (!inherits(bt, "try-error")) {
      out[i, 1L] <- unname(bt$statistic)
      out[i, 2L] <- bt$p.value
    }
  }
  rownames(out) <- paste0("Lag[", lags, "]")
  out
}

.cgd_arch_lm <- function(z, lags = c(3L, 5L, 7L)) {
  z <- z[is.finite(z)]
  x <- z^2
  out <- matrix(NA_real_, nrow = length(lags), ncol = 3L)
  colnames(out) <- c("Statistic", "d.o.f", "P-Value")
  for (i in seq_along(lags)) {
    m <- as.integer(lags[i])
    if (length(x) <= m + 5L) next
    em <- stats::embed(x, m + 1L)
    yy <- em[, 1L]
    xx <- em[, -1L, drop = FALSE]
    dat <- data.frame(yy = yy, xx)
    fit <- try(stats::lm(yy ~ ., data = dat), silent = TRUE)
    if (!inherits(fit, "try-error")) {
      r2 <- summary(fit)$r.squared
      stat <- length(yy) * r2
      out[i, ] <- c(stat, m, stats::pchisq(stat, df = m, lower.tail = FALSE))
    }
  }
  rownames(out) <- paste0("ARCH Lag[", lags, "]")
  out
}

.cgd_sign_bias <- function(z) {
  z <- z[is.finite(z)]
  if (length(z) < 20L) return(NULL)
  e2 <- z[-1L]^2
  lagz <- z[-length(z)]
  sign_neg <- as.numeric(lagz < 0)
  neg_size <- sign_neg * lagz
  pos_size <- (1 - sign_neg) * lagz

  one_test <- function(x) {
    fit <- try(stats::lm(e2 ~ x), silent = TRUE)
    if (inherits(fit, "try-error")) return(c(`t-value` = NA_real_, prob = NA_real_))
    co <- summary(fit)$coefficients
    if (nrow(co) < 2L) return(c(`t-value` = NA_real_, prob = NA_real_))
    c(`t-value` = co[2L, 3L], prob = co[2L, 4L])
  }

  joint_fit <- try(stats::lm(e2 ~ sign_neg + neg_size + pos_size), silent = TRUE)
  joint <- c(`t-value` = NA_real_, prob = NA_real_)
  if (!inherits(joint_fit, "try-error")) {
    fs <- summary(joint_fit)$fstatistic
    if (!is.null(fs)) joint <- c(`t-value` = unname(fs[1L]),
                                 prob = stats::pf(fs[1L], fs[2L], fs[3L], lower.tail = FALSE))
  }

  out <- rbind(`Sign Bias` = one_test(sign_neg),
               `Negative Sign Bias` = one_test(neg_size),
               `Positive Sign Bias` = one_test(pos_size),
               `Joint Effect` = joint)
  sig <- ifelse(out[, "prob"] < 0.01, "***",
                ifelse(out[, "prob"] < 0.05, "**",
                       ifelse(out[, "prob"] < 0.10, "*", "")))
  cbind(out, sig = sig)
}

.cgd_pearson_gof <- function(z, groups = c(20L, 30L, 40L, 50L)) {
  z <- z[is.finite(z)]
  zsd <- stats::sd(z)
  if (!is.finite(zsd) || zsd <= 0) zsd <- 1
  z <- (z - mean(z)) / zsd
  out <- matrix(NA_real_, nrow = length(groups), ncol = 3L)
  colnames(out) <- c("group", "statistic", "p-value(g-1)")
  for (i in seq_along(groups)) {
    g <- as.integer(groups[i])
    cuts <- stats::qnorm(seq(0, 1, length.out = g + 1L))
    cuts[1L] <- -Inf
    cuts[length(cuts)] <- Inf
    bin <- cut(z, breaks = cuts, include.lowest = TRUE, labels = FALSE)
    obs <- tabulate(bin, nbins = g)
    expct <- length(z) / g
    stat <- sum((obs - expct)^2 / expct)
    out[i, ] <- c(g, stat, stats::pchisq(stat, df = g - 1L, lower.tail = FALSE))
  }
  rownames(out) <- seq_along(groups)
  out
}

.cgd_nyblom <- function(object) {
  G <- .cgd_score_contributions(object)
  out <- numeric(ncol(G))
  for (j in seq_len(ncol(G))) {
    g <- G[, j]
    g <- g - mean(g, na.rm = TRUE)
    vg <- stats::var(g, na.rm = TRUE)
    if (!is.finite(vg) || vg <= 0) {
      out[j] <- NA_real_
    } else {
      cs <- cumsum(g)
      n <- length(g)
      out[j] <- sum(cs^2) / (n^2 * vg)
    }
  }
  names(out) <- colnames(G)
  list(joint = sum(out, na.rm = TRUE), individual = out)
}

.cgd_diagnostics <- function(object) {
  idx <- .cgd_effective_index(object)
  z <- object$residuals[idx]
  pq <- max(1L, object$q + object$s)
  lags_resid <- c(1L, 3L * pq - 1L, 5L * pq - 1L)
  lags_sq <- c(1L, 3L * pq - 1L, 5L * pq - 1L)
  list(
    ljung_resid = .cgd_ljung_box(z, lags_resid, fitdf = 0L),
    ljung_sq = .cgd_ljung_box(z^2, lags_sq, fitdf = sum(object$coefficients[-1L] != 0)),
    arch_lm = .cgd_arch_lm(z),
    nyblom = .cgd_nyblom(object),
    sign_bias = .cgd_sign_bias(z),
    pearson = .cgd_pearson_gof(z)
  )
}

.cgd_print_coefmat <- function(tab) {
  stats::printCoefmat(tab, digits = 6, signif.stars = FALSE,
                      has.Pvalue = TRUE, P.values = TRUE, na.print = "NA")
}

.cgd_flag_text <- function(p, alpha = 0.05, ok = "no visible issue", bad = "inspect") {
  if (!is.finite(p)) return("not available")
  if (p < alpha) bad else ok
}

.cgd_minp <- function(x, col = "p-value") {
  if (is.null(x)) return(NA_real_)
  if (is.matrix(x) || is.data.frame(x)) {
    nm <- colnames(x)
    j <- which(tolower(nm) %in% tolower(c(col, "P-Value", "p-value", "prob", "p-value(g-1)")))[1L]
    if (is.na(j)) return(NA_real_)
    val <- suppressWarnings(min(as.numeric(x[, j]), na.rm = TRUE))
    if (!is.finite(val)) return(NA_real_)
    return(val)
  }
  NA_real_
}

.cgd_print_diagnostics <- function(dg, object) {
  idx <- .cgd_effective_index(object)
  z <- object$residuals[idx]
  z2 <- z^2

  .cgd_section("residual evidence panel")
  ev <- data.frame(
    check = c("linear carry-over", "variance carry-over", "ARCH regression echo",
              "sign/size asymmetry", "normal-bin calibration"),
    p_min_or_index = c(.cgd_minp(dg$ljung_resid), .cgd_minp(dg$ljung_sq),
                       .cgd_minp(dg$arch_lm), .cgd_minp(dg$sign_bias, "prob"),
                       .cgd_minp(dg$pearson, "p-value(g-1)")),
    reading = c(
      .cgd_flag_text(.cgd_minp(dg$ljung_resid), bad = "serial pattern remains"),
      .cgd_flag_text(.cgd_minp(dg$ljung_sq), bad = "second-moment pattern remains"),
      .cgd_flag_text(.cgd_minp(dg$arch_lm), bad = "ARCH echo remains"),
      .cgd_flag_text(.cgd_minp(dg$sign_bias, "prob"), bad = "asymmetry likely"),
      .cgd_flag_text(.cgd_minp(dg$pearson, "p-value(g-1)"), bad = "tails/shape mismatch")
    ),
    stringsAsFactors = FALSE
  )
  ev$p_min_or_index <- signif(ev$p_min_or_index, 5)
  print(ev, row.names = FALSE, right = FALSE)

  .cgd_subsection("lag diagnostics used by the evidence panel")
  cat("standardized residual portmanteau p-values:\n")
  print(round(dg$ljung_resid, 6))
  cat("squared standardized residual portmanteau p-values:\n")
  print(round(dg$ljung_sq, 6))
  cat("ARCH echo regression p-values:\n")
  print(round(dg$arch_lm, 6))

  .cgd_subsection("score-path drift screen")
  cat("joint drift index : ", round(dg$nyblom$joint, 6), "\n", sep = "")
  ind <- matrix(dg$nyblom$individual, ncol = 1L)
  colnames(ind) <- "drift_index"
  print(round(ind, 6))
  cat("Reading: these are descriptive score-process screens, not post-selection critical values.\n")

  if (!is.null(dg$sign_bias)) {
    .cgd_subsection("directional asymmetry regression")
    print(dg$sign_bias, quote = FALSE)
  }

  .cgd_subsection("probability-bin calibration")
  print(round(dg$pearson, 6))

  invisible(ev)
}

print.cgd_garch <- function(x, ...) {
  print(summary(x, diagnostics = TRUE))
  invisible(x)
}

summary.cgd_garch <- function(object, diagnostics = TRUE, ...) {
  tabs <- .cgd_parameter_tables(object)
  ans <- list(
    call = match.call(),
    coefficients = object$coefficients,
    active = object$coefficients != 0,
    parameter_table = tabs$standard,
    robust_parameter_table = tabs$robust,
    information_criteria = .cgd_info_criteria(object),
    diagnostics = if (isTRUE(diagnostics)) .cgd_diagnostics(object) else NULL,
    persistence = sum(object$coefficients[-1L]),
    loglik = object$loglik,
    aic = object$aic,
    bic = object$bic,
    nobs = object$n_eff,
    convergence = object$convergence,
    object = object
  )
  class(ans) <- "summary.cgd_garch"
  ans
}

print.summary.cgd_garch <- function(x, ...) {
  object <- x$object
  cat("\n")
  cat("cgdgarch fit dossier\n")
  .cgd_rule(char = "=")
  cat("model        : ", .cgd_model_label(object), "\n", sep = "")
  cat("penalty      : ", .cgd_penalty_label(object$penalty), " | lambda = ", signif(object$lambda, 8), "\n", sep = "")
  cat("criterion    : penalized Gaussian QMLE solved by coordinate-gradient descent\n")
  cat("engine       : ", object$engine, " | observations used = ", object$n_eff, " of ", object$nobs, "\n", sep = "")
  cat("mean handling: constant mean estimated as ", signif(object$mu, 8),
      "; variance recursion uses demeaned returns\n", sep = "")

  .cgd_section("coefficient ledger")
  tab <- x$parameter_table
  status <- ifelse(rownames(tab) %in% c("mu", "omega"), "unpenalized",
                   ifelse(abs(tab[, "Estimate"]) > 0, "retained", "zeroed"))
  tab2 <- cbind(tab, status = status)
  print(tab2, quote = FALSE)
  cat("Note: standard errors are approximate diagonal QMLE screens; use them as diagnostics, not final post-selection inference.\n")

  .cgd_section("sandwich uncertainty screen")
  robust <- x$robust_parameter_table
  robust2 <- cbind(robust, status = status)
  print(robust2, quote = FALSE)

  .cgd_section("fit scorecard")
  ic <- x$information_criteria
  score <- data.frame(
    metric = c("loglik", "objective", names(ic)),
    value = c(x$loglik, object$objective, as.numeric(ic)),
    scale = c("total", "penalized per effective observation", rep("per effective observation", length(ic))),
    stringsAsFactors = FALSE
  )
  score$value <- signif(score$value, 7)
  print(score, row.names = FALSE, right = FALSE)

  .cgd_section("shrinkage map and volatility memory")
  co <- object$coefficients
  ledger <- data.frame(
    term = names(co),
    estimate = signif(as.numeric(co), 7),
    role = c("variance floor", rep("lag coefficient", length(co) - 1L)),
    decision = c("always retained", ifelse(co[-1L] != 0, "kept by penalty", "set to zero")),
    stringsAsFactors = FALSE
  )
  print(ledger, row.names = FALSE, right = FALSE)
  cat("memory proxy sum(alpha,beta): ", round(x$persistence, 6), "\n", sep = "")
  cat("solver: ", if (x$convergence$converged) "converged" else "stopped before tolerance",
      " after ", x$convergence$iterations, " cycles; tol = ",
      signif(x$convergence$tolerance, 6), "\n", sep = "")

  if (!is.null(x$diagnostics)) .cgd_print_diagnostics(x$diagnostics, object)

  .cgd_section("variance trace availability")
  cat("Use cgd_variance_trace(fit) and plot_variance_trace(fit) for fitted versus filtered sigma^2.\n")
  cat("Use cgd_error_dependence(fit), plot_error_acf(fit), and plot_error_pacf(fit) for error^2 dependence.\n")
  cat("Use cgd_diagnostic_summary(fit) for Shiny-ready interpreted diagnostics.\n")

  .cgd_section("runtime")
  cat("elapsed seconds: ", round(object$elapsed, 6), "\n", sep = "")
  .cgd_rule(char = "=")
  invisible(x)
}

coef.cgd_garch <- function(object, include_mean = FALSE, ...) {
  if (isTRUE(include_mean)) c(mu = object$mu, object$coefficients) else object$coefficients
}

fitted.cgd_garch <- function(object, ...) object$fitted

residuals.cgd_garch <- function(object, standardize = TRUE, ...) {
  if (standardize) object$residuals else object$y
}

predict.cgd_garch <- function(object, n.ahead = 10L, ...) {
  n.ahead <- as.integer(n.ahead)
  if (n.ahead < 1L) stop("`n.ahead` must be positive.")
  y2 <- object$y^2
  sig <- object$sigma2
  par <- object$coefficients
  q <- object$q; s <- object$s
  e2_hist <- y2
  s_hist <- sig
  fc <- numeric(n.ahead)
  for (h in seq_len(n.ahead)) {
    v <- par[1L]
    if (q > 0) for (i in seq_len(q)) {
      idx <- length(e2_hist) - i + 1L
      v <- v + par[1L + i] * if (idx >= 1L) e2_hist[idx] else mean(y2)
    }
    if (s > 0) for (j in seq_len(s)) {
      idx <- length(s_hist) - j + 1L
      v <- v + par[1L + q + j] * if (idx >= 1L) s_hist[idx] else mean(sig)
    }
    fc[h] <- max(v, 1e-12)
    e2_hist <- c(e2_hist, fc[h])
    s_hist <- c(s_hist, fc[h])
  }
  data.frame(h = seq_len(n.ahead), sigma2_forecast = fc, sigma_forecast = sqrt(fc))
}

plot.cgd_garch <- function(x, which = 1:4, ...) {
  old <- par(no.readonly = TRUE); on.exit(par(old))
  par(mfrow = c(2, 2))
  if (1 %in% which) plot(x$residuals, type = "l", main = "Standardized residuals", ylab = "Residual", xlab = "Time")
  if (2 %in% which) stats::acf(x$residuals^2, main = "ACF of squared residuals")
  if (3 %in% which) { qqnorm(x$residuals, main = "Normal Q-Q plot"); qqline(x$residuals) }
  if (4 %in% which) plot(sqrt(x$sigma2), type = "l", main = "Conditional volatility", ylab = "sigma", xlab = "Time")
  invisible(x)
}
