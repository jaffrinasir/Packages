# Empirical workflow comparison --------------------------------------------

.cgd_rugarch_extract <- function(object, what = c("sigma", "coef", "convergence")) {
  what <- match.arg(what)
  if (!methods::is(object, "uGARCHfit")) {
    stop("`object` is not a rugarch uGARCHfit object.")
  }

  # Current rugarch stores the fitted coefficients, conditional standard
  # deviations and solver convergence code in the documented `fit` slot.
  # Reading these values first avoids fragile S4 dispatch when rugarch is
  # loaded with requireNamespace() but is not attached to the search path.
  if ("fit" %in% methods::slotNames(object)) {
    fs <- methods::slot(object, "fit")
    if (is.list(fs)) {
      if (what == "sigma" && !is.null(fs$sigma) && length(fs$sigma)) {
        return(fs$sigma)
      }
      if (what == "coef" && !is.null(fs$coef) && length(fs$coef)) {
        return(fs$coef)
      }
      if (what == "convergence" && !is.null(fs$convergence)) {
        return(fs$convergence)
      }
    }
  }

  # Fall back to the registered S4 extractors documented by rugarch.
  meth <- try(methods::selectMethod(what, signature = class(object)[1L],
                                    optional = TRUE), silent = TRUE)
  if (!inherits(meth, "try-error") && is.function(meth)) {
    ans <- try(meth(object), silent = TRUE)
    if (!inherits(ans, "try-error")) return(ans)
  }

  stop("Could not extract `", what, "` from the rugarch fit object. ",
       "Check the installed rugarch version and inspect names(object@fit).")
}

.cgd_fgarch_extract <- function(object, what = c("sigma", "coef", "convergence")) {
  what <- match.arg(what)
  if (!methods::is(object, "fGARCH")) {
    stop("`object` is not an fGARCH fit object.")
  }

  # fGarch formally stores conditional standard deviations in `sigma.t`.
  if (what == "sigma" && "sigma.t" %in% methods::slotNames(object)) {
    ans <- methods::slot(object, "sigma.t")
    if (length(ans)) return(ans)
  }

  # The fit slot contains the estimated coefficients and optimization details.
  # Current releases use `coef`; some older releases exposed `par`, so support
  # both names before attempting S4 method dispatch.
  if ("fit" %in% methods::slotNames(object)) {
    fs <- methods::slot(object, "fit")
    if (is.list(fs)) {
      if (what == "coef") {
        if (!is.null(fs$coef) && length(fs$coef)) return(fs$coef)
        if (!is.null(fs$par) && length(fs$par)) return(fs$par)
      }
      if (what == "convergence") {
        if (!is.null(fs$convergence)) return(fs$convergence)
        if (!is.null(fs$code)) return(fs$code)
      }
    }
  }

  if (what == "coef") {
    meth <- try(methods::selectMethod("coef", signature = "fGARCH",
                                      optional = TRUE), silent = TRUE)
    if (!inherits(meth, "try-error") && is.function(meth)) {
      ans <- try(meth(object), silent = TRUE)
      if (!inherits(ans, "try-error")) return(ans)
    }
  }

  stop("Could not extract `", what, "` from the fGarch fit object. ",
       "Check the installed fGarch version and inspect slotNames(object).")
}

.cgd_align_metric <- function(x, ref) {
  x <- as.numeric(x); ref <- as.numeric(ref)
  m <- min(length(x), length(ref))
  if (m < 3L) return(c(rmse = NA_real_, correlation = NA_real_))
  x <- tail(x, m); ref <- tail(ref, m)
  ok <- is.finite(x) & is.finite(ref)
  if (sum(ok) < 3L) return(c(rmse = NA_real_, correlation = NA_real_))
  c(rmse = sqrt(mean((x[ok] - ref[ok])^2)),
    correlation = stats::cor(x[ok], ref[ok]))
}

.cgd_coef_row <- function(engine, co, all_names, available = TRUE, converged = NA) {
  vals <- rep(NA_real_, length(all_names)); names(vals) <- all_names
  if (length(co)) {
    common <- intersect(names(co), all_names)
    vals[common] <- as.numeric(co[common])
  }
  data.frame(engine = engine, available = available, converged = converged,
             as.list(vals), check.names = FALSE, stringsAsFactors = FALSE)
}

#' Compare a standard fixed-order GARCH fit across R workflows
#'
#' Fits the same fixed ARCH/GARCH order with unpenalized `cgdgarch` and, when
#' installed, `rugarch` and `fGarch`. The function is intended as an empirical
#' context check, not as a claim that the packages use identical optimization,
#' initialization, or likelihood conventions.
#'
#' @param y Numeric return series.
#' @param q ARCH order.
#' @param s GARCH order.
#' @param true_sigma2 Optional latent conditional variance from a simulation.
#' @param max_iter Maximum coordinate cycles for the cgdgarch unpenalized fit.
#' @param include Character vector containing any of `"cgdgarch"`, `"rugarch"`,
#'   and `"fGarch"`.
#' @param strict Logical. If `TRUE`, any requested external benchmark that is
#'   missing, fails to fit, or cannot provide coefficients/conditional sigma
#'   causes an informative error instead of an `NA` benchmark row.
#' @param ... Additional arguments passed to `cgd_garch()`.
#' @return An object of class `cgd_garch_comparison` with coefficient table,
#'   variance-agreement metrics, benchmark `status`, fitted objects, and notes.
#' @examples
#' set.seed(22)
#' sim <- simulate_garch(500, omega = 0.02, alpha = 0.1, beta = 0.8,
#'                       return_details = TRUE)
#' cmp <- cgd_compare_garch(sim$y, q = 1, s = 1, true_sigma2 = sim$sigma2,
#'                         max_iter = 50)
#' cmp
cgd_compare_garch <- function(y, q = 1L, s = 1L, true_sigma2 = NULL,
                              max_iter = 300L,
                              include = c("cgdgarch", "rugarch", "fGarch"),
                              strict = FALSE, ...) {
  y <- as.numeric(y); y <- y[is.finite(y)]
  if (length(y) < 30L) stop("`y` must contain at least 30 finite observations.")
  q <- as.integer(q); s <- as.integer(s)
  if (q < 0L || s < 0L || q + s < 1L) stop("At least one of `q` and `s` must be positive.")
  include <- intersect(unique(include), c("cgdgarch", "rugarch", "fGarch"))
  if (!length(include)) stop("No supported workflow selected in `include`.")
  all_names <- c("mu", make_names(q, s))
  mu_common <- mean(y)
  y_centered <- y - mu_common
  fits <- list(); sigma2 <- list(); rows <- list(); notes <- character(0); status <- list()

  if ("cgdgarch" %in% include) {
    fit_cgd <- cgd_garch(y, q = q, s = s,
                         penalty = penalty_alasso(weights = rep(1, q + s)),
                         lambda = 0, max_iter = max_iter, ...)
    fits$cgdgarch <- fit_cgd
    sigma2$cgdgarch <- fit_cgd$sigma2
    rows[["cgdgarch"]] <- .cgd_coef_row("cgdgarch", coef(fit_cgd, include_mean = TRUE),
                                        all_names, TRUE, fit_cgd$convergence$converged)
    status[["cgdgarch"]] <- data.frame(engine = "cgdgarch", installed = TRUE,
                                         fit_ok = TRUE, coef_ok = TRUE,
                                         sigma_ok = TRUE,
                                         converged = isTRUE(fit_cgd$convergence$converged),
                                         message = "ok", stringsAsFactors = FALSE)
  }

  if ("rugarch" %in% include) {
    if (requireNamespace("rugarch", quietly = TRUE)) {
      rg <- try({
        spec <- rugarch::ugarchspec(
          variance.model = list(model = "sGARCH", garchOrder = c(q, s)),
          mean.model = list(armaOrder = c(0, 0), include.mean = FALSE),
          distribution.model = "norm")
        rugarch::ugarchfit(spec = spec, data = y_centered, solver = "hybrid")
      }, silent = TRUE)
      if (!inherits(rg, "try-error")) {
        fits$rugarch <- rg

        sig_rg <- try(.cgd_rugarch_extract(rg, "sigma"), silent = TRUE)
        if (!inherits(sig_rg, "try-error")) {
          sigma2$rugarch <- as.numeric(sig_rg)^2
        } else {
          notes <- c(notes, paste("rugarch sigma extraction failed:", as.character(sig_rg)))
        }

        co_rg <- try(.cgd_rugarch_extract(rg, "coef"), silent = TRUE)
        if (!inherits(co_rg, "try-error")) {
          co <- c(mu = mu_common, as.numeric(co_rg))
          names(co) <- c("mu", names(co_rg))
        } else {
          co <- numeric(0)
          notes <- c(notes, paste("rugarch coefficient extraction failed:", as.character(co_rg)))
        }

        conv_rg <- try(.cgd_rugarch_extract(rg, "convergence"), silent = TRUE)
        conv_ok <- if (inherits(conv_rg, "try-error")) NA else isTRUE(as.numeric(conv_rg)[1L] == 0)
        rows[["rugarch"]] <- .cgd_coef_row("rugarch", co, all_names, TRUE, conv_ok)
        status[["rugarch"]] <- data.frame(
          engine = "rugarch", installed = TRUE, fit_ok = TRUE,
          coef_ok = !inherits(co_rg, "try-error"),
          sigma_ok = !inherits(sig_rg, "try-error"), converged = conv_ok,
          message = if (!inherits(co_rg, "try-error") && !inherits(sig_rg, "try-error")) "ok" else
            paste(c(if (inherits(co_rg, "try-error")) "coefficient extraction failed" else NULL,
                    if (inherits(sig_rg, "try-error")) "sigma extraction failed" else NULL), collapse = "; "),
          stringsAsFactors = FALSE)
      } else {
        rows[["rugarch"]] <- .cgd_coef_row("rugarch", numeric(0), all_names, TRUE, FALSE)
        notes <- c(notes, paste("rugarch fit failed:", as.character(rg)))
        status[["rugarch"]] <- data.frame(engine = "rugarch", installed = TRUE,
                                           fit_ok = FALSE, coef_ok = FALSE,
                                           sigma_ok = FALSE, converged = FALSE,
                                           message = paste("fit failed:", as.character(rg)),
                                           stringsAsFactors = FALSE)
      }
    } else {
      rows[["rugarch"]] <- .cgd_coef_row("rugarch", numeric(0), all_names, FALSE, NA)
      notes <- c(notes, "rugarch is not installed; its row is reported as unavailable.")
      status[["rugarch"]] <- data.frame(engine = "rugarch", installed = FALSE,
                                         fit_ok = FALSE, coef_ok = FALSE,
                                         sigma_ok = FALSE, converged = NA,
                                         message = "not installed", stringsAsFactors = FALSE)
    }
  }

  if ("fGarch" %in% include) {
    if (requireNamespace("fGarch", quietly = TRUE)) {
      fg <- try({
        form <- stats::as.formula(sprintf("~ garch(%d, %d)", q, s))
        fGarch::garchFit(formula = form, data = y_centered, include.mean = FALSE,
                         cond.dist = "norm", trace = FALSE)
      }, silent = TRUE)
      if (!inherits(fg, "try-error")) {
        fits$fGarch <- fg
        sig_fg <- try(.cgd_fgarch_extract(fg, "sigma"), silent = TRUE)
        if (!inherits(sig_fg, "try-error")) {
          sigma2$fGarch <- as.numeric(sig_fg)^2
        } else {
          notes <- c(notes, paste("fGarch sigma extraction failed:", as.character(sig_fg)))
        }

        co_fg <- try(.cgd_fgarch_extract(fg, "coef"), silent = TRUE)
        if (!inherits(co_fg, "try-error")) {
          co <- c(mu = mu_common, as.numeric(co_fg))
          names(co) <- c("mu", names(co_fg))
        } else {
          co <- numeric(0)
          notes <- c(notes, paste("fGarch coefficient extraction failed:", as.character(co_fg)))
        }

        conv_fg <- try(.cgd_fgarch_extract(fg, "convergence"), silent = TRUE)
        conv_ok <- if (inherits(conv_fg, "try-error")) NA else isTRUE(as.numeric(conv_fg)[1L] == 0)
        rows[["fGarch"]] <- .cgd_coef_row("fGarch", co, all_names, TRUE, conv_ok)
        status[["fGarch"]] <- data.frame(
          engine = "fGarch", installed = TRUE, fit_ok = TRUE,
          coef_ok = !inherits(co_fg, "try-error"),
          sigma_ok = !inherits(sig_fg, "try-error"), converged = conv_ok,
          message = if (!inherits(co_fg, "try-error") && !inherits(sig_fg, "try-error")) "ok" else
            paste(c(if (inherits(co_fg, "try-error")) "coefficient extraction failed" else NULL,
                    if (inherits(sig_fg, "try-error")) "sigma extraction failed" else NULL), collapse = "; "),
          stringsAsFactors = FALSE)
      } else {
        rows[["fGarch"]] <- .cgd_coef_row("fGarch", numeric(0), all_names, TRUE, FALSE)
        notes <- c(notes, paste("fGarch fit failed:", as.character(fg)))
        status[["fGarch"]] <- data.frame(engine = "fGarch", installed = TRUE,
                                          fit_ok = FALSE, coef_ok = FALSE,
                                          sigma_ok = FALSE, converged = FALSE,
                                          message = paste("fit failed:", as.character(fg)),
                                          stringsAsFactors = FALSE)
      }
    } else {
      rows[["fGarch"]] <- .cgd_coef_row("fGarch", numeric(0), all_names, FALSE, NA)
      notes <- c(notes, "fGarch is not installed; its row is reported as unavailable.")
      status[["fGarch"]] <- data.frame(engine = "fGarch", installed = FALSE,
                                        fit_ok = FALSE, coef_ok = FALSE,
                                        sigma_ok = FALSE, converged = NA,
                                        message = "not installed", stringsAsFactors = FALSE)
    }
  }

  coef_table <- do.call(rbind, rows)
  rownames(coef_table) <- NULL
  metric_rows <- list()
  ref_cgd <- sigma2$cgdgarch
  for (nm in names(rows)) {
    sig <- sigma2[[nm]]
    truth <- c(rmse = NA_real_, correlation = NA_real_)
    vs_cgd <- c(rmse = NA_real_, correlation = NA_real_)
    if (!is.null(sig) && !is.null(true_sigma2)) truth <- .cgd_align_metric(sig, true_sigma2)
    if (!is.null(sig) && !is.null(ref_cgd)) vs_cgd <- .cgd_align_metric(sig, ref_cgd)
    metric_rows[[nm]] <- data.frame(
      engine = nm,
      sigma2_RMSE_vs_truth = unname(truth["rmse"]),
      sigma2_cor_vs_truth = unname(truth["correlation"]),
      sigma2_RMSE_vs_cgdgarch = unname(vs_cgd["rmse"]),
      sigma2_cor_vs_cgdgarch = unname(vs_cgd["correlation"]),
      stringsAsFactors = FALSE)
  }
  metrics <- do.call(rbind, metric_rows); rownames(metrics) <- NULL
  notes <- c(
    "For comparability, all engines use the same sample-mean centering; rugarch and fGarch are fitted without a separate mean term and the common sample mean is reported as mu.",
    notes
  )
  status_table <- if (length(status)) do.call(rbind, status) else data.frame()
  rownames(status_table) <- NULL

  if (isTRUE(strict)) {
    external <- intersect(include, c("rugarch", "fGarch"))
    bad <- external[vapply(external, function(nm) {
      st <- status[[nm]]
      is.null(st) || !isTRUE(st$installed[1L]) || !isTRUE(st$fit_ok[1L]) ||
        !isTRUE(st$coef_ok[1L]) || !isTRUE(st$sigma_ok[1L])
    }, logical(1))]
    if (length(bad)) {
      detail <- vapply(bad, function(nm) {
        st <- status[[nm]]
        if (is.null(st)) return(paste0(nm, ": no status returned"))
        paste0(nm, ": ", st$message[1L])
      }, character(1))
      stop("External GARCH comparison did not complete successfully. ",
           paste(detail, collapse = " | "),
           ". Install/update the benchmark packages and rerun. ",
           "Use strict = FALSE and inspect `$status` and `$notes` for diagnostics.")
    }
  }

  ans <- list(coefficients = coef_table, variance_metrics = metrics, status = status_table,
              fits = fits, sigma2 = sigma2, q = q, s = s, n = length(y),
              common_mean = mu_common, notes = notes)
  class(ans) <- "cgd_garch_comparison"
  ans
}

print.cgd_garch_comparison <- function(x, ...) {
  cat("cgdgarch fixed-order empirical comparison\n")
  cat("model order: (q = ", x$q, ", s = ", x$s, ") | n = ", x$n, "\n", sep = "")
  cat("\nCoefficient estimates\n")
  print(x$coefficients, row.names = FALSE, digits = 6)
  cat("\nConditional-variance agreement\n")
  print(x$variance_metrics, row.names = FALSE, digits = 6)
  if (!is.null(x$status) && nrow(x$status)) {
    cat("\nBenchmark engine status\n")
    print(x$status, row.names = FALSE)
  }
  if (length(x$notes)) {
    cat("\nNotes\n- ", paste(x$notes, collapse = "\n- "), "\n", sep = "")
  }
  invisible(x)
}
