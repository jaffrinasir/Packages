# Generated manually for cgdgarch. Do not edit by hand after running Rcpp::compileAttributes().

cgdgarch_sigma2_cpp <- function(err2, par, q, s) {
  .Call("_cgdgarch_cgdgarch_sigma2_cpp", err2, par, q, s, PACKAGE = "cgdgarch")
}

cgdgarch_score_diag_cpp <- function(err2, par, q, s) {
  .Call("_cgdgarch_cgdgarch_score_diag_cpp", err2, par, q, s, PACKAGE = "cgdgarch")
}

cgdgarch_qll_cpp <- function(err2, par, q, s) {
  .Call("_cgdgarch_cgdgarch_qll_cpp", err2, par, q, s, PACKAGE = "cgdgarch")
}
