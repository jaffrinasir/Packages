#' Automatic lambda grid for cgdgarch
#'
#' Constructs a lambda grid from a data-dependent upper bound. The default
#' dyadic grid follows the same idea as the Shiny prototype: starting from
#' `lambda_max`, halve the value repeatedly and optionally insert midpoints.
#'
#' @param y Numeric return series.
#' @param q Maximum ARCH order.
#' @param s Maximum GARCH order.
#' @param penalty Penalty object.
#' @param lambda_max Optional user-supplied maximum lambda.
#' @param lambda_min Optional user-supplied minimum lambda.
#' @param lambda_min_ratio Ratio used to set `lambda_min = lambda_max * lambda_min_ratio`.
#' @param nlambda Number of lambda values for the logarithmic grid.
#' @param grid_depth Number of dyadic halvings for `method = "dyadic"`.
#' @param method Either `"dyadic"` or `"log"`.
#' @param gamma Adaptive LASSO gamma used when estimating weights for lambda-max.
#' @param fit_unpenalized Logical; estimate an unpenalized model to construct adaptive weights.
#' @param ... Additional arguments passed to the short unpenalized fit.
#' @return An object of class `cgd_lambda_grid`.
lambda_grid_cgd <- function(y, q = 1L, s = 1L, penalty = penalty_alasso(),
                            lambda_max = NULL, lambda_min = NULL,
                            lambda_min_ratio = 1e-4, nlambda = 30L,
                            grid_depth = NULL, method = c("dyadic", "log"),
                            gamma = NULL, fit_unpenalized = TRUE, ...) {
  y <- validate_series(y)
  q <- as.integer(q); s <- as.integer(s)
  if (q < 0L || s < 0L || q + s < 1L) stop("At least one of `q` and `s` must be positive.")
  method <- match.arg(method)
  p <- q + s

  weights <- NULL
  if (identical(penalty$name, "alasso")) {
    if (!is.null(gamma)) penalty$gamma <- gamma
    if (!is.null(penalty$weights)) {
      weights <- as.numeric(penalty$weights)
    } else if (isTRUE(fit_unpenalized)) {
      dots <- list(...)
      if (is.null(dots$max_iter)) dots$max_iter <- 100L
      if (is.null(dots$tol)) dots$tol <- 1e-5
      fit0 <- do.call(cgd_garch, c(list(
        y = y, q = q, s = s,
        penalty = penalty_alasso(weights = rep(1, p), gamma = penalty$gamma),
        lambda = 0
      ), dots))
      weights <- 1 / pmax(abs(coef(fit0)[-1L]), 1e-6)^(if (is.null(penalty$gamma)) 2 else penalty$gamma)
    } else {
      weights <- rep(1, p)
    }
  }

  if (is.null(lambda_max)) {
    null_par <- c(mean(y^2), rep(0, p))
    names(null_par) <- make_names(q, s)
    sc <- score_diag(y, null_par, q, s, use_cpp = TRUE)$score[-1L]
    fac <- penalty_slope_factor_zero(penalty, weights = weights, p = p)
    fac[!is.finite(fac) | fac <= 0] <- NA_real_
    lambda_max <- max(abs(sc) / fac, na.rm = TRUE)
    if (!is.finite(lambda_max) || lambda_max <= 0) lambda_max <- 1
  }

  lambda_max <- as.numeric(lambda_max)[1L]
  if (!is.finite(lambda_max) || lambda_max <= 0) stop("`lambda_max` must be positive.")
  if (is.null(lambda_min)) {
    if (method == "dyadic" && !is.null(grid_depth)) {
      lambda_min <- lambda_max / (2^as.integer(grid_depth))
    } else {
      lambda_min <- lambda_max * lambda_min_ratio
    }
  }
  lambda_min <- as.numeric(lambda_min)[1L]
  if (!is.finite(lambda_min) || lambda_min <= 0 || lambda_min >= lambda_max) {
    stop("`lambda_min` must be positive and smaller than `lambda_max`.")
  }

  if (method == "dyadic") {
    if (is.null(grid_depth)) grid_depth <- ceiling(log(lambda_max / lambda_min, base = 2))
    grid_depth <- max(1L, as.integer(grid_depth))
    l1 <- lambda_max / (2^(0:grid_depth))
    l2 <- if (length(l1) > 1L) (l1[-length(l1)] + l1[-1L]) / 2 else numeric(0)
    lambda <- sort(unique(c(l1, l2, lambda_min)), decreasing = TRUE)
    lambda <- lambda[lambda >= lambda_min & lambda <= lambda_max]
  } else {
    nlambda <- max(2L, as.integer(nlambda))
    lambda <- exp(seq(log(lambda_max), log(lambda_min), length.out = nlambda))
    grid_depth <- NA_integer_
  }

  ans <- list(
    lambda = lambda,
    lambda_max = lambda_max,
    lambda_min = min(lambda),
    lambda_min_requested = lambda_min,
    lambda_min_ratio = lambda_min / lambda_max,
    grid_depth = grid_depth,
    method = method,
    q = q,
    s = s,
    penalty = penalty,
    weights = weights
  )
  class(ans) <- "cgd_lambda_grid"
  ans
}

print.cgd_lambda_grid <- function(x, ...) {
  cat("cgdgarch lambda grid\n")
  cat("method:", x$method, " | lambda_max:", signif(x$lambda_max, 5),
      " | lambda_min:", signif(x$lambda_min, 5),
      " | length:", length(x$lambda), "\n")
  if (!is.na(x$grid_depth)) cat("grid_depth:", x$grid_depth, "dyadic halvings\n")
  invisible(x)
}

cv_cgd_garch <- function(y, q = 1L, s = 1L, penalty = penalty_alasso(),
                         lambda = NULL, nfolds = 5L, min_train = NULL,
                         lambda_min_ratio = 1e-4, nlambda = 30L,
                         grid_depth = NULL, lambda_method = c("dyadic", "log"),
                         fit_unpenalized = TRUE, ...) {
  y <- validate_series(y)
  n <- length(y)
  nfolds <- as.integer(nfolds)
  if (nfolds < 2L) stop("`nfolds` must be at least 2.")
  lambda_grid <- NULL
  if (is.null(lambda)) {
    lambda_grid <- lambda_grid_cgd(y, q = q, s = s, penalty = penalty,
                                   lambda_min_ratio = lambda_min_ratio,
                                   nlambda = nlambda, grid_depth = grid_depth,
                                   method = match.arg(lambda_method),
                                   fit_unpenalized = fit_unpenalized, ...)
    lambda <- lambda_grid$lambda
  }
  if (is.null(min_train)) min_train <- max(50L, floor(n * 0.5))
  starts <- unique(round(seq(min_train, n - 5L, length.out = nfolds)))
  lambda <- sort(unique(as.numeric(lambda)), decreasing = TRUE)
  cv <- matrix(NA_real_, nrow = length(lambda), ncol = length(starts))
  for (li in seq_along(lambda)) {
    for (fi in seq_along(starts)) {
      tr <- seq_len(starts[fi])
      te <- seq.int(starts[fi] + 1L, min(n, starts[fi] + ceiling((n - min_train) / nfolds)))
      fit <- cgd_garch(y[tr], q = q, s = s, penalty = penalty, lambda = lambda[li], ...)
      hist_idx <- tail(tr, max(q, s, 1L))
      sig <- compute_sigma2(y[c(hist_idx, te)], fit$coefficients, q, s, use_cpp = TRUE)
      out_sig <- tail(sig, length(te))
      cv[li, fi] <- mean(log(out_sig) + y[te]^2 / out_sig)
    }
  }
  m <- rowMeans(cv, na.rm = TRUE)
  se <- apply(cv, 1L, stats::sd, na.rm = TRUE) / sqrt(nfolds)
  ans <- list(lambda = lambda, cvm = m, cvse = se, lambda.min = lambda[which.min(m)],
              nfolds = nfolds, q = q, s = s, penalty = penalty, lambda_grid = lambda_grid)
  class(ans) <- "cgd_cv"
  ans
}

print.cgd_cv <- function(x, ...) {
  cat("Cross-validation for cgd_garch\n")
  cat("lambda.min:", x$lambda.min, "\n")
  invisible(x)
}

plot.cgd_cv <- function(x, ...) {
  plot(log(x$lambda), x$cvm, type = "b", xlab = "log(lambda)", ylab = "CV QMLE loss", ...)
  arrows(log(x$lambda), x$cvm - x$cvse, log(x$lambda), x$cvm + x$cvse,
         angle = 90, code = 3, length = 0.03)
  abline(v = log(x$lambda.min), lty = 2)
  invisible(x)
}

solution_path <- function(y, q = 1L, s = 1L, penalty = penalty_scad(),
                          lambda = NULL, lambda_min_ratio = 1e-4,
                          nlambda = 30L, grid_depth = NULL,
                          lambda_method = c("dyadic", "log"),
                          fit_unpenalized = TRUE, warm_start = TRUE, ...) {
  y <- validate_series(y)
  lambda_grid <- NULL
  if (is.null(lambda)) {
    lambda_grid <- lambda_grid_cgd(y, q = q, s = s, penalty = penalty,
                                   lambda_min_ratio = lambda_min_ratio,
                                   nlambda = nlambda, grid_depth = grid_depth,
                                   method = match.arg(lambda_method),
                                   fit_unpenalized = fit_unpenalized, ...)
    lambda <- lambda_grid$lambda
  }
  lambda <- sort(unique(as.numeric(lambda)), decreasing = TRUE)
  co <- NULL
  fits <- vector("list", length(lambda))
  start <- NULL
  for (i in seq_along(lambda)) {
    fits[[i]] <- cgd_garch(y, q = q, s = s, penalty = penalty, lambda = lambda[i], start = start, ...)
    if (isTRUE(warm_start)) start <- coef(fits[[i]])
    co <- rbind(co, coef(fits[[i]]))
  }
  rownames(co) <- paste0("lambda=", signif(lambda, 3))
  ans <- list(lambda = lambda, coefficients = co, fits = fits, penalty = penalty,
              q = q, s = s, lambda_grid = lambda_grid)
  class(ans) <- "cgd_path"
  ans
}

.cgd_plot_coefficient_path <- function(lambda, coefficients,
                                       x_axis = c("log_lambda", "lambda"),
                                       include_intercept = TRUE,
                                       selected_lambda = NULL,
                                       selected_label = "selected lambda",
                                       col = NULL, lty = NULL, lwd = 1.6,
                                       legend_pos = "topright", legend = TRUE,
                                       main = "Penalization solution path", ...) {
  x_axis <- match.arg(x_axis)
  lambda <- as.numeric(lambda)
  co <- as.matrix(coefficients)
  if (nrow(co) != length(lambda)) {
    stop("The coefficient matrix must have one row per lambda value.")
  }
  if (!isTRUE(include_intercept) && ncol(co) > 1L) {
    co <- co[, -1L, drop = FALSE]
  }
  if (!ncol(co)) stop("No coefficients are available to plot.")

  if (x_axis == "log_lambda") {
    if (any(!is.finite(lambda) | lambda <= 0)) {
      stop("`x_axis = \"log_lambda\"` requires strictly positive lambda values; use `x_axis = \"lambda\"` when the path contains lambda = 0.")
    }
    xx <- log(lambda)
    xlab <- "log(lambda)"
  } else {
    xx <- lambda
    xlab <- "lambda"
  }

  npar <- ncol(co)
  if (is.null(col)) col <- grDevices::hcl.colors(npar, palette = "Dark 3")
  col <- rep(col, length.out = npar)
  if (is.null(lty)) lty <- rep(c(1, 2, 3, 4, 5, 6), length.out = npar)
  lty <- rep(lty, length.out = npar)
  lwd <- rep(lwd, length.out = npar)

  graphics::matplot(
    xx, co, type = "l", col = col, lty = lty, lwd = lwd,
    xlab = xlab, ylab = "Coefficient estimate", main = main, ...
  )
  graphics::abline(h = 0, col = "grey85", lty = 1)

  selected_x <- NULL
  if (!is.null(selected_lambda)) {
    selected_lambda <- as.numeric(selected_lambda)[1L]
    if (!is.finite(selected_lambda) || selected_lambda < 0) {
      stop("`selected_lambda` must be a finite non-negative value.")
    }
    if (x_axis == "log_lambda" && selected_lambda <= 0) {
      stop("A positive `selected_lambda` is required when `x_axis = \"log_lambda\"`.")
    }
    selected_x <- if (x_axis == "log_lambda") log(selected_lambda) else selected_lambda
    graphics::abline(v = selected_x, col = "grey30", lty = 3, lwd = 1.1)
  }

  if (isTRUE(legend)) {
    labs <- colnames(co)
    if (is.null(labs)) labs <- paste0("parameter", seq_len(npar))
    leg_col <- col
    leg_lty <- lty
    leg_lwd <- lwd
    if (!is.null(selected_x)) {
      labs <- c(labs, selected_label)
      leg_col <- c(leg_col, "grey30")
      leg_lty <- c(leg_lty, 3)
      leg_lwd <- c(leg_lwd, 1.1)
    }
    graphics::legend(
      legend_pos, legend = labs, col = leg_col, lty = leg_lty,
      lwd = leg_lwd, bty = "n", cex = 0.8
    )
  }
  invisible(list(x = xx, coefficients = co, selected_x = selected_x))
}

plot.cgd_path <- function(x,
                          x_axis = c("log_lambda", "lambda"),
                          include_intercept = TRUE,
                          selected_lambda = NULL,
                          col = NULL, lty = NULL, lwd = 1.6,
                          legend_pos = "topright", legend = TRUE, ...) {
  .cgd_plot_coefficient_path(
    lambda = x$lambda,
    coefficients = x$coefficients,
    x_axis = x_axis,
    include_intercept = include_intercept,
    selected_lambda = selected_lambda,
    selected_label = "selected lambda",
    col = col, lty = lty, lwd = lwd,
    legend_pos = legend_pos, legend = legend,
    main = "Penalization solution path",
    ...
  )
  invisible(x)
}
