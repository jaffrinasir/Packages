# Penalty constructors -------------------------------------------------------

new_penalty <- function(name, pars = list()) {
  structure(c(list(name = name), pars), class = "cgd_penalty")
}

#' Adaptive LASSO penalty
#'
#' @param weights Optional adaptive weights for the non-intercept coefficients.
#' @param gamma Exponent used when adaptive weights are constructed internally.
#' @return A penalty object of class `cgd_penalty`.
penalty_alasso <- function(weights = NULL, gamma = 2) {
  if (!is.null(weights) && any(!is.finite(weights) | weights < 0)) {
    stop("`weights` must be non-negative finite values.")
  }
  if (!is.numeric(gamma) || length(gamma) != 1L || gamma < 0) {
    stop("`gamma` must be a non-negative scalar.")
  }
  new_penalty("alasso", list(weights = weights, gamma = gamma))
}

penalty_scad <- function(a = 3.7) {
  if (!is.numeric(a) || length(a) != 1L || a <= 2) stop("`a` must be a scalar greater than 2.")
  new_penalty("scad", list(a = a))
}

penalty_mcp <- function(gamma = 3) {
  if (!is.numeric(gamma) || length(gamma) != 1L || gamma <= 1) stop("`gamma` must be a scalar greater than 1.")
  new_penalty("mcp", list(gamma = gamma))
}

#' Arctan penalty
#'
#' @param scale Positive transition scale in the implemented form
#'   `(2 / pi) * atan(t / scale)`. Smaller values make the penalty flatten
#'   closer to zero; larger values extend the near-linear region.
#' @return A penalty object of class `cgd_penalty`.
penalty_arctan <- function(scale = 0.1) {
  if (!is.numeric(scale) || length(scale) != 1L || !is.finite(scale) || scale <= 0) {
    stop("`scale` must be a positive finite scalar.")
  }
  new_penalty("arctan", list(scale = scale))
}

#' Laplace penalty
#'
#' @param scale Positive transition scale in the implemented form
#'   `1 - exp(-t / scale)`. At `t = scale`, the normalized penalty reaches
#'   `1 - exp(-1)` of its upper bound.
#' @return A penalty object of class `cgd_penalty`.
penalty_laplace <- function(scale = 0.5) {
  if (!is.numeric(scale) || length(scale) != 1L || !is.finite(scale) || scale <= 0) {
    stop("`scale` must be a positive finite scalar.")
  }
  new_penalty("laplace", list(scale = scale))
}

penalty_clg <- function(alpha = 0.7, kappa = 2) {
  if (alpha < 0 || alpha > 1) stop("`alpha` must be in [0, 1].")
  if (kappa <= 0) stop("`kappa` must be positive.")
  new_penalty("clg", list(alpha = alpha, kappa = kappa))
}

print.cgd_penalty <- function(x, ...) {
  pars <- x[setdiff(names(x), "name")]
  if (length(pars)) {
    txt <- paste(names(pars), unlist(pars), sep = " = ", collapse = ", ")
    cat(toupper(x$name), " penalty (", txt, ")\n", sep = "")
  } else {
    cat(toupper(x$name), " penalty\n", sep = "")
  }
  invisible(x)
}

penalty_value <- function(theta, lambda, penalty, weights = NULL) {
  t <- abs(theta)
  name <- penalty$name
  if (lambda <= 0 || length(t) == 0L) return(rep(0, length(t)))
  if (name == "alasso") {
    if (is.null(weights)) weights <- rep(1, length(t))
    return(lambda * weights * t)
  }
  if (name == "scad") {
    a <- penalty$a
    out <- numeric(length(t))
    i1 <- t <= lambda
    i2 <- t > lambda & t <= a * lambda
    i3 <- t > a * lambda
    out[i1] <- lambda * t[i1]
    out[i2] <- (-t[i2]^2 + 2 * a * lambda * t[i2] - lambda^2) / (2 * (a - 1))
    out[i3] <- (a + 1) * lambda^2 / 2
    return(out)
  }
  if (name == "mcp") {
    gamma <- penalty$gamma
    return(ifelse(t <= gamma * lambda, lambda * t - t^2 / (2 * gamma), gamma * lambda^2 / 2))
  }
  if (name == "arctan") return(lambda * (2 / pi) * atan(t / penalty$scale))
  if (name == "laplace") return(lambda * (1 - exp(-t / penalty$scale)))
  if (name == "clg") return(lambda * (penalty$alpha * t + (1 - penalty$alpha) * (1 - exp(-penalty$kappa * t^2))))
  stop("Unknown penalty.")
}

penalty_derivative <- function(theta, lambda, penalty, weights = NULL) {
  penalty_slope_abs(abs(theta), lambda, penalty, weights) * sign(theta)
}

penalty_slope_abs <- function(t, lambda, penalty, weights = NULL) {
  t <- abs(t)
  name <- penalty$name
  if (lambda <= 0 || length(t) == 0L) return(rep(0, length(t)))
  if (name == "alasso") {
    if (is.null(weights)) weights <- rep(1, length(t))
    return(lambda * weights)
  }
  if (name == "scad") {
    a <- penalty$a
    return(ifelse(t <= lambda, lambda, ifelse(t <= a * lambda, (a * lambda - t) / (a - 1), 0)))
  }
  if (name == "mcp") return(pmax(lambda - t / penalty$gamma, 0))
  if (name == "arctan") return(lambda * (2 / pi) * penalty$scale / (penalty$scale^2 + t^2))
  if (name == "laplace") return(lambda * exp(-t / penalty$scale) / penalty$scale)
  if (name == "clg") {
    return(lambda * (penalty$alpha + 2 * (1 - penalty$alpha) * penalty$kappa * t * exp(-penalty$kappa * t^2)))
  }
  stop("Unknown penalty.")
}

penalty_slope_factor_zero <- function(penalty, weights = NULL, p = length(weights)) {
  name <- penalty$name
  if (name == "alasso") {
    if (is.null(weights)) weights <- rep(1, p)
    return(weights)
  }
  if (name == "scad") return(rep(1, p))
  if (name == "mcp") return(rep(1, p))
  if (name == "arctan") return(rep((2 / pi) / penalty$scale, p))
  if (name == "laplace") return(rep(1 / penalty$scale, p))
  if (name == "clg") return(rep(penalty$alpha, p))
  stop("Unknown penalty.")
}
