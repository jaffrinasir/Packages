validate_series <- function(y) {
  if (is.null(y)) stop("`y` is required.")
  y <- as.numeric(y)
  y <- y[is.finite(y)]
  if (length(y) < 30L) stop("`y` must contain at least 30 finite observations.")
  y - mean(y)
}

make_names <- function(q, s) {
  c("omega", paste0("alpha", seq_len(q)), if (s > 0) paste0("beta", seq_len(s)) else character(0))
}

compute_sigma2_r <- function(y, par, q, s) {
  n <- length(y)
  h <- max(q, s, 1L)
  sigma2 <- rep(stats::var(y), n)
  e2 <- y^2
  omega <- max(par[1L], .Machine$double.eps)
  if (n <= h) return(pmax(sigma2, 1e-12))
  for (tt in (h + 1L):n) {
    v <- omega
    if (q > 0L) for (i in seq_len(q)) v <- v + par[1L + i] * e2[tt - i]
    if (s > 0L) for (j in seq_len(s)) v <- v + par[1L + q + j] * sigma2[tt - j]
    sigma2[tt] <- max(v, 1e-12)
  }
  sigma2
}

compute_sigma2 <- function(y, par, q, s, use_cpp = TRUE) {
  y <- as.numeric(y)
  par <- as.numeric(par)
  if (isTRUE(use_cpp)) {
    out <- try(cgdgarch_sigma2_cpp(y^2, par, as.integer(q), as.integer(s)), silent = TRUE)
    if (!inherits(out, "try-error")) return(as.numeric(out))
  }
  compute_sigma2_r(y, par, q, s)
}

score_diag <- function(y, par, q, s, use_cpp = TRUE) {
  if (isTRUE(use_cpp)) {
    out <- try(cgdgarch_score_diag_cpp(y^2, as.numeric(par), as.integer(q), as.integer(s)), silent = TRUE)
    if (!inherits(out, "try-error")) return(out)
  }
  p <- length(par)
  base <- qll(y, par, q, s, use_cpp = FALSE)
  score <- numeric(p)
  for (j in seq_len(p)) {
    eps <- max(1e-6, abs(par[j]) * 1e-4)
    p1 <- p2 <- par
    p1[j] <- p1[j] + eps
    p2[j] <- max(p2[j] - eps, 0)
    if (p2[j] == par[j]) {
      score[j] <- (qll(y, p1, q, s, use_cpp = FALSE) - base) / eps
    } else {
      score[j] <- (qll(y, p1, q, s, use_cpp = FALSE) - qll(y, p2, q, s, use_cpp = FALSE)) / (p1[j] - p2[j])
    }
  }
  list(score = score, qdiag = rep(1, p), sigma2 = compute_sigma2_r(y, par, q, s), n_eff = length(y) - max(q, s))
}

qll <- function(y, par, q, s, use_cpp = TRUE) {
  if (isTRUE(use_cpp)) {
    out <- try(cgdgarch_qll_cpp(y^2, as.numeric(par), as.integer(q), as.integer(s)), silent = TRUE)
    if (!inherits(out, "try-error") && is.finite(out)) return(as.numeric(out))
  }
  sig <- compute_sigma2(y, par, q, s, use_cpp = FALSE)
  h <- max(q, s, 1L)
  mean(log(sig[(h + 1L):length(y)]) + y[(h + 1L):length(y)]^2 / sig[(h + 1L):length(y)])
}

objective <- function(y, par, q, s, lambda, penalty, weights, use_cpp = TRUE) {
  qll(y, par, q, s, use_cpp = use_cpp) + sum(penalty_value(par[-1L], lambda, penalty, weights))
}

initial_par <- function(y, q, s) {
  p <- 1L + q + s
  v <- stats::var(y)
  out <- rep(0.02 / max(q + s, 1L), p)
  out[1L] <- max(v * 0.05, 1e-6)
  if (s > 0L) out[(2L + q):p] <- 0.7 / s
  names(out) <- make_names(q, s)
  out
}

make_adaptive_weights <- function(par, penalty, q, s, eps = 1e-6) {
  p <- q + s
  if (!identical(penalty$name, "alasso")) return(NULL)
  if (!is.null(penalty$weights)) {
    if (length(penalty$weights) != p) stop("adaptive LASSO weights must have length q + s.")
    return(as.numeric(penalty$weights))
  }
  gamma <- if (is.null(penalty$gamma)) 2 else penalty$gamma
  1 / pmax(abs(par[-1L]), eps)^gamma
}

#' Fit a penalized ARCH/GARCH model
#'
#' @param y Numeric vector of returns.
#' @param q Maximum ARCH order.
#' @param s Maximum GARCH order.
#' @param penalty Penalty object created by a `penalty_*()` function. The default is adaptive LASSO.
#' @param lambda Non-negative scalar tuning parameter.
#' @param max_iter Maximum number of coordinate cycles.
#' @param tol Convergence tolerance based on the maximum absolute parameter change.
#' @param step_size Initial step size used by the coordinate update.
#' @param armijo Reduction factor for backtracking line search.
#' @param threshold Values below this number are reported as zero.
#' @param use_cpp Logical; use compiled Rcpp recursions, score, and diagonal information when available.
#' @param start Optional starting parameter vector of length `1 + q + s`.
#' @param verbose Logical; print progress messages.
#' @return An object of class `cgd_garch`.
#' @examples
#' set.seed(1)
#' y <- simulate_garch(300, omega = 0.02, alpha = c(0.12, 0, 0.08), beta = 0.75)
#' fit <- cgd_garch(y, q = 3, s = 1, penalty = penalty_scad(), lambda = 0.001)
#' coef(fit)
cgd_garch <- function(y, q = 1L, s = 1L, penalty = penalty_alasso(), lambda = 0.001,
                      max_iter = 300L, tol = 1e-6, step_size = 1,
                      armijo = 0.5, threshold = 1e-8, use_cpp = TRUE,
                      start = NULL, verbose = FALSE) {
  start_time <- proc.time()[["elapsed"]]
  y_original <- as.numeric(y)
  y_original <- y_original[is.finite(y_original)]
  if (length(y_original) < 30L) stop("`y` must contain at least 30 finite observations.")
  mu_hat <- mean(y_original)
  y <- validate_series(y)
  q <- as.integer(q); s <- as.integer(s)
  if (q < 0L || s < 0L || q + s < 1L) stop("At least one of `q` and `s` must be positive.")
  if (is.null(lambda) || length(lambda) != 1L || !is.finite(lambda) || lambda < 0) {
    stop("`lambda` must be a non-negative scalar. Use lambda_grid_cgd(), cv_cgd_garch(), or solution_path() to automate a lambda grid.")
  }
  if (!inherits(penalty, "cgd_penalty")) stop("`penalty` must be created by a penalty_*() function.")

  par <- if (is.null(start)) initial_par(y, q, s) else as.numeric(start)
  if (length(par) != 1L + q + s) stop("`start` must have length 1 + q + s.")
  par <- pmax(par, 0)
  par[1L] <- max(par[1L], 1e-12)
  names(par) <- make_names(q, s)

  weights <- make_adaptive_weights(par, penalty, q, s)
  old_obj <- objective(y, par, q, s, lambda, penalty, weights, use_cpp = use_cpp)
  iter <- 0L
  converged <- FALSE

  for (iter in seq_len(max_iter)) {
    old <- par
    for (j in seq_along(par)) {
      sd <- score_diag(y, par, q, s, use_cpp = use_cpp)
      Sn <- as.numeric(sd$score)
      Qd <- as.numeric(sd$qdiag)
      if (!is.finite(Qd[j]) || Qd[j] <= 1e-12) Qd[j] <- 1
      if (!is.finite(Sn[j])) next

      if (j == 1L) {
        target <- max(1e-12, par[j] - Sn[j] / Qd[j])
      } else {
        slope <- penalty_slope_abs(max(abs(par[j]), threshold), lambda, penalty, weights[j - 1L])
        z <- par[j] - Sn[j] / Qd[j]
        target <- max(0, z - slope / Qd[j])
      }

      direction <- target - par[j]
      if (!is.finite(direction) || abs(direction) < 1e-14) next
      step <- step_size
      accepted <- FALSE
      while (step >= 1e-10) {
        cand <- par
        cand[j] <- par[j] + step * direction
        cand[j] <- if (j == 1L) max(cand[j], 1e-12) else max(cand[j], 0)
        cand_obj <- objective(y, cand, q, s, lambda, penalty, weights, use_cpp = use_cpp)
        if (is.finite(cand_obj) && cand_obj <= old_obj + 1e-10) {
          par <- cand
          old_obj <- cand_obj
          accepted <- TRUE
          break
        }
        step <- step * armijo
      }

      if (!accepted && j > 1L) {
        grad <- Sn[j] + penalty_derivative(par[j], lambda, penalty, weights[j - 1L])
        direction <- -grad / Qd[j]
        step <- step_size
        while (is.finite(direction) && step >= 1e-10) {
          cand <- par
          cand[j] <- max(0, par[j] + step * direction)
          cand_obj <- objective(y, cand, q, s, lambda, penalty, weights, use_cpp = use_cpp)
          if (is.finite(cand_obj) && cand_obj <= old_obj + 1e-10) {
            par <- cand
            old_obj <- cand_obj
            break
          }
          step <- step * armijo
        }
      }
    }

    delta <- max(abs(par - old))
    if (verbose && (iter %% 25L == 0L)) message("iteration ", iter, ": objective = ", signif(old_obj, 6))
    if (delta < tol) {
      converged <- TRUE
      break
    }
  }

  par[abs(par) < threshold] <- 0
  par[1L] <- max(par[1L], 1e-12)
  names(par) <- make_names(q, s)
  sig <- compute_sigma2(y, par, q, s, use_cpp = use_cpp)
  h <- max(q, s, 1L)
  idx <- (h + 1L):length(y)
  n_eff <- length(idx)
  active <- sum(par[-1L] != 0)
  k_total <- active + 2L # mean plus variance intercept plus active lag coefficients
  loglik <- -0.5 * sum(log(sig[idx]) + y[idx]^2 / sig[idx])
  elapsed <- proc.time()[["elapsed"]] - start_time
  out <- list(
    coefficients = par,
    sigma2 = sig,
    fitted = sig,
    residuals = y / sqrt(sig),
    y = y,
    y_original = y_original,
    mu = mu_hat,
    mean_model = "constant",
    distribution = "norm",
    q = q,
    s = s,
    penalty = penalty,
    lambda = lambda,
    weights = weights,
    objective = old_obj,
    loglik = loglik,
    n_eff = n_eff,
    nobs = length(y),
    npars = k_total,
    aic = -2 * loglik + 2 * k_total,
    bic = -2 * loglik + log(n_eff) * k_total,
    engine = if (isTRUE(use_cpp)) "Rcpp" else "R",
    elapsed = elapsed,
    convergence = list(converged = converged, iterations = iter, tolerance = tol)
  )
  class(out) <- "cgd_garch"
  out
}

cgd_arch <- function(y, q = 1L, ...) cgd_garch(y = y, q = q, s = 0L, ...)
