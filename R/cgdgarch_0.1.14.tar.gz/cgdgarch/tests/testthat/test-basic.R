test_that("penalty constructors work", {
  expect_s3_class(penalty_scad(), "cgd_penalty")
  expect_s3_class(penalty_alasso(gamma = 2), "cgd_penalty")
  expect_error(penalty_mcp(gamma = 1))

  pa <- penalty_arctan(scale = 0.2)
  pl <- penalty_laplace(scale = 0.4)
  expect_equal(pa$scale, 0.2)
  expect_equal(pl$scale, 0.4)
  expect_false("gamma" %in% names(pa))
  expect_false("eps" %in% names(pl))
  expect_error(penalty_arctan(scale = 0))
  expect_error(penalty_laplace(scale = -1))
})

test_that("scale parameter gives the documented penalty shapes", {
  t <- c(0, 0.2, 0.8)
  pa <- penalty_arctan(scale = 0.2)
  pl <- penalty_laplace(scale = 0.4)
  expect_equal(
    cgdgarch:::penalty_value(t, lambda = 1, penalty = pa),
    (2 / pi) * atan(t / 0.2)
  )
  expect_equal(
    cgdgarch:::penalty_value(t, lambda = 1, penalty = pl),
    1 - exp(-t / 0.4)
  )
})

test_that("lambda grid is automated", {
  set.seed(10)
  y <- simulate_garch(120, omega = 0.02, alpha = c(0.1, 0), beta = 0.75)
  lg <- lambda_grid_cgd(y, q = 2, s = 1, penalty = penalty_scad(), grid_depth = 4,
                        fit_unpenalized = FALSE)
  expect_s3_class(lg, "cgd_lambda_grid")
  expect_true(lg$lambda_max > lg$lambda_min)
  expect_true(length(lg$lambda) >= 4)
})

test_that("model fitting returns expected object", {
  set.seed(1)
  y <- simulate_garch(120, omega = 0.02, alpha = c(0.1, 0), beta = 0.75)
  fit <- cgd_garch(y, q = 2, s = 1, lambda = 0.001, max_iter = 5)
  expect_s3_class(fit, "cgd_garch")
  expect_equal(length(coef(fit)), 4)
  expect_true(all(fitted(fit) > 0))
  expect_true(fit$engine %in% c("Rcpp", "R"))
})

test_that("prediction works", {
  set.seed(2)
  y <- simulate_garch(120)
  fit <- cgd_garch(y, q = 1, s = 1, max_iter = 5)
  fc <- predict(fit, n.ahead = 3)
  expect_equal(nrow(fc), 3)
  expect_true(all(fc$sigma2_forecast > 0))
})


test_that("distinctive cgdgarch dossier output is available", {
  set.seed(3)
  y <- simulate_garch(100)
  fit <- cgd_garch(y, q = 1, s = 1, max_iter = 3)
  out <- capture.output(print(fit))
  expect_true(any(grepl("cgdgarch fit dossier", out)))
  expect_true(any(grepl("coefficient ledger", out)))
  expect_true(any(grepl("residual evidence panel", out)))
  expect_equal(length(coef(fit, include_mean = TRUE)), 4)
})

test_that("Shiny-ready diagnostics and plots return data", {
  set.seed(4)
  y <- simulate_garch(140)
  fit <- cgd_garch(y, q = 1, s = 1, max_iter = 5)
  vt <- cgd_variance_trace(fit)
  expect_true(all(c("fitted_sigma2", "filtered_sigma2") %in% names(vt)))
  ed <- cgd_error_dependence(fit, lag.max = 10)
  expect_s3_class(ed, "cgd_error_dependence")
  expect_equal(nrow(ed$acf), 10)
  ds <- cgd_diagnostic_summary(fit)
  expect_s3_class(ds, "cgd_diagnostic_summary")
  expect_true("interpretation" %in% names(ds))
})

test_that("lambda IC path is produced", {
  set.seed(5)
  y <- simulate_garch(140)
  ip <- cgd_lambda_ic_path(y, q = 1, s = 1, grid_depth = 3, max_iter = 5, fit_unpenalized = FALSE)
  expect_s3_class(ip, "cgd_ic_path")
  expect_true(all(c("lambda", "BIC", "active_lags") %in% names(ip$path)))
  expect_equal(nrow(ip$best), 1)
})


test_that("simulation can return latent variance", {
  set.seed(8)
  sim <- simulate_garch(120, return_details = TRUE)
  expect_s3_class(sim, "cgd_garch_simulation")
  expect_equal(length(sim$y), 120)
  expect_equal(length(sim$sigma2), 120)
  expect_true(all(sim$sigma2 > 0))
})

test_that("VaR forecasts and calibration objects are produced", {
  set.seed(9)
  y <- simulate_garch(160)
  fit <- cgd_garch(y, q = 1, s = 1, lambda = 0, max_iter = 5)
  vr <- cgd_var(fit, level = c(0.95, 0.99), n.ahead = 2)
  expect_s3_class(vr, "cgd_var")
  expect_equal(nrow(vr), 4)
  expect_true(all(vr$VaR_loss >= 0))
  bt <- cgd_var_backtest(fit, level = 0.95)
  expect_s3_class(bt, "cgd_var_backtest")
  expect_true(all(c("test", "statistic", "p_value") %in% names(bt$tests)))
  expect_true(is.function(getS3method("plot", "cgd_var_backtest")))
})

test_that("comparison helper always returns cgdgarch row", {
  set.seed(10)
  sim <- simulate_garch(140, return_details = TRUE)
  cmp <- cgd_compare_garch(sim$y, q = 1, s = 1, true_sigma2 = sim$sigma2,
                           include = "cgdgarch", max_iter = 5)
  expect_s3_class(cmp, "cgd_garch_comparison")
  expect_equal(cmp$coefficients$engine, "cgdgarch")
  expect_true("sigma2_RMSE_vs_truth" %in% names(cmp$variance_metrics))
})

test_that("comparison helper handles rugarch S4 extractors when available", {
  skip_if_not_installed("rugarch")
  set.seed(11)
  sim <- simulate_garch(180, return_details = TRUE)
  cmp <- expect_no_error(
    cgd_compare_garch(sim$y, q = 1, s = 1, true_sigma2 = sim$sigma2,
                      include = c("cgdgarch", "rugarch"), max_iter = 5)
  )
  expect_s3_class(cmp, "cgd_garch_comparison")
  rr <- cmp$coefficients[cmp$coefficients$engine == "rugarch", ]
  expect_true(all(is.finite(unlist(rr[c("omega", "alpha1", "beta1")]))))
  vm <- cmp$variance_metrics[cmp$variance_metrics$engine == "rugarch", ]
  expect_true(is.finite(vm$sigma2_RMSE_vs_truth))
  expect_true(is.finite(vm$sigma2_cor_vs_truth))
  st <- cmp$status[cmp$status$engine == "rugarch", ]
  expect_true(st$fit_ok && st$coef_ok && st$sigma_ok)
})


test_that("comparison helper handles fGarch S4 extractors when available", {
  skip_if_not_installed("fGarch")
  set.seed(12)
  sim <- simulate_garch(180, return_details = TRUE)
  cmp <- expect_no_error(
    cgd_compare_garch(sim$y, q = 1, s = 1, true_sigma2 = sim$sigma2,
                      include = c("cgdgarch", "fGarch"), max_iter = 5)
  )
  expect_s3_class(cmp, "cgd_garch_comparison")
  rr <- cmp$coefficients[cmp$coefficients$engine == "fGarch", ]
  expect_true(all(is.finite(unlist(rr[c("omega", "alpha1", "beta1")]))))
  vm <- cmp$variance_metrics[cmp$variance_metrics$engine == "fGarch", ]
  expect_true(is.finite(vm$sigma2_RMSE_vs_truth))
  expect_true(is.finite(vm$sigma2_cor_vs_truth))
  st <- cmp$status[cmp$status$engine == "fGarch", ]
  expect_true(st$fit_ok && st$coef_ok && st$sigma_ok)
})


test_that("IC path stores coefficients and enhanced plots are available", {
  set.seed(13)
  y <- simulate_garch(140)
  ip <- cgd_lambda_ic_path(y, q = 2, s = 1, grid_depth = 3,
                           max_iter = 5, fit_unpenalized = FALSE)
  expect_true(is.matrix(ip$coefficients))
  expect_equal(nrow(ip$coefficients), nrow(ip$path))
  expect_equal(ncol(ip$coefficients), 4L)

  tf <- tempfile(fileext = ".pdf")
  grDevices::pdf(tf)
  expect_silent(plot(ip))
  expect_silent(plot(ip, type = "coefficients", x_axis = "lambda"))
  grDevices::dev.off()
  unlink(tf)
})

test_that("solution path can be plotted against actual lambda", {
  set.seed(14)
  y <- simulate_garch(140)
  sp <- solution_path(y, q = 2, s = 1, grid_depth = 3,
                      max_iter = 5, fit_unpenalized = FALSE)
  expect_s3_class(sp, "cgd_path")
  expect_equal(nrow(sp$coefficients), length(sp$lambda))

  tf <- tempfile(fileext = ".pdf")
  grDevices::pdf(tf)
  expect_silent(plot(sp, x_axis = "lambda", include_intercept = FALSE))
  expect_silent(plot(sp, selected_lambda = sp$lambda[2L]))
  grDevices::dev.off()
  unlink(tf)
})
