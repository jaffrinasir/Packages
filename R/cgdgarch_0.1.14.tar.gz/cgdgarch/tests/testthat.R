library(testthat)
library(cgdgarch)
test_check("cgdgarch")
