\name{cgd_var}
\alias{cgd_var}
\alias{print.cgd_var}
\title{Gaussian conditional Value-at-Risk forecasts from a cgdgarch model}
\description{
Converts conditional mean and volatility forecasts from a fitted \code{cgd_garch} object into lower-tail return quantiles and positive long-position loss Value-at-Risk (VaR) under the package's current Gaussian quasi-likelihood convention.
}
\usage{
cgd_var(object, level = c(0.95, 0.99), n.ahead = 1L,
        portfolio_value = 1, include_mean = TRUE, positive = TRUE)

\method{print}{cgd_var}(x, ...)
}
\arguments{
\item{object}{A fitted \code{cgd_garch} object.}
\item{level}{One or more confidence levels strictly between zero and one.}
\item{n.ahead}{Positive forecast horizon.}
\item{portfolio_value}{Positive position value used to scale loss VaR. Use 1 for return-scale VaR.}
\item{include_mean}{Logical; include the fitted constant mean in the conditional quantile.}
\item{positive}{Logical; return positive long-position loss VaR. If \code{TRUE}, negative loss values are truncated at zero while the raw return quantile remains available.}
\item{x}{A \code{cgd_var} object.}
\item{...}{Currently unused.}
}
\details{
For confidence level \eqn{c}, the package computes the lower-tail conditional return quantile
\deqn{q_{t+h}(1-c)=\hat\mu+\hat\sigma_{t+h|t}\Phi^{-1}(1-c).}
For a long position of value \eqn{V}, positive loss VaR is \eqn{-Vq_{t+h}(1-c)} under the stated sign convention.

The current implementation deliberately uses the Gaussian quantile because \code{cgd_garch()} currently fits a Gaussian quasi-likelihood only. It does not silently substitute Student-t or skewed innovations. This limitation matters particularly at extreme confidence levels, where tail-distribution misspecification can materially affect VaR.

Use \code{cgd_var_backtest()} to evaluate a sequence of VaR thresholds. A genuine predictive backtest requires out-of-sample realized returns and matching one-step-ahead volatility forecasts.
}
\value{A data frame of class \code{cgd_var} containing horizon, confidence level, tail probability, mean and volatility forecasts, return quantile, positive loss VaR, and portfolio value.}
\examples{
set.seed(12)
y <- simulate_garch(300)
fit <- cgd_garch(y, q = 1, s = 1, lambda = 0, max_iter = 30)
cgd_var(fit, level = c(0.95, 0.99), n.ahead = 3)
}
