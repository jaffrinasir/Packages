\name{cgd_compare_garch}
\alias{cgd_compare_garch}
\alias{print.cgd_garch_comparison}
\title{Compare a Fixed-Order GARCH Fit Across R Workflows}
\description{
Fits the same fixed ARCH/GARCH order with unpenalized \code{cgdgarch} and,
when requested, \code{rugarch} and \code{fGarch}. The function returns
coefficient estimates, conditional-variance agreement metrics, and an explicit
benchmark-status table.
}
\usage{
cgd_compare_garch(y, q = 1L, s = 1L, true_sigma2 = NULL,
                  max_iter = 300L,
                  include = c("cgdgarch", "rugarch", "fGarch"),
                  strict = FALSE, ...)

\method{print}{cgd_garch_comparison}(x, ...)
}
\arguments{
\item{y}{Numeric return series.}
\item{q}{ARCH order shared across available engines.}
\item{s}{GARCH order shared across available engines.}
\item{true_sigma2}{Optional latent conditional-variance sequence, typically supplied by \code{simulate_garch(..., return_details = TRUE)}.}
\item{max_iter}{Maximum coordinate cycles for the \code{cgdgarch} fit.}
\item{include}{Character vector selecting any of \code{"cgdgarch"}, \code{"rugarch"}, and \code{"fGarch"}.}
\item{strict}{Logical. If \code{TRUE}, each requested external benchmark must be installed, fit successfully, and return both coefficients and conditional sigma values. Otherwise an informative error is raised instead of silently returning an all-\code{NA} row.}
\item{...}{Additional arguments passed to \code{cgd_garch()}.}
\item{x}{A \code{cgd_garch_comparison} object.}
}
\details{
This helper is a numerical context check, not an equivalence test or package
ranking. All engines are aligned to the same sample-mean centering. The
external benchmark fits use no separate mean term, while the common sample
mean is reported as \code{mu}. The variance model uses the same requested
fixed order and Gaussian innovation assumption where supported.

The function deliberately does not attach optional packages. For current
\code{rugarch} and \code{fGarch} S4 objects, documented fitted-object slots are
used first for robust extraction, followed by registered S4 methods when
needed. The returned \code{status} component records whether each benchmark
package was installed, fitted successfully, and yielded coefficients and
conditional sigma values.

With \code{strict = FALSE} (the default), unavailable or failed external
benchmarks are retained as \code{NA} rows and the reason is reported in
\code{status} and \code{notes}. With \code{strict = TRUE}, such failures stop
the calculation. The strict mode is recommended for reproducible benchmark
tables because it prevents a successful document render from hiding missing
external results.
}
\value{
An object of class \code{cgd_garch_comparison} containing
\code{coefficients}, \code{variance_metrics}, \code{status}, fitted objects,
conditional-variance sequences, model order, common mean, and diagnostic notes.
}
\examples{
set.seed(22)
sim <- simulate_garch(500, omega = 0.02, alpha = 0.1, beta = 0.8,
                      return_details = TRUE)
cmp <- cgd_compare_garch(sim$y, q = 1, s = 1,
                         true_sigma2 = sim$sigma2,
                         include = "cgdgarch", max_iter = 50)
cmp
}
