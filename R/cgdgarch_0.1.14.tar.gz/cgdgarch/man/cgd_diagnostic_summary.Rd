\name{cgd_diagnostic_summary}
\alias{cgd_diagnostic_summary}
\alias{print.cgd_diagnostic_summary}
\title{Interpreted diagnostic summary}
\description{
Returns a compact diagnostic table with plain-language interpretations. The table is intended for Shiny dashboards, reports, and quick model screening.
}
\usage{
cgd_diagnostic_summary(object, alpha = 0.05)
}
\arguments{
\item{object}{A fitted \code{cgd_garch} object.}
\item{alpha}{P-value threshold used for rule-of-thumb interpretation.}
}
\value{A data frame of class \code{cgd_diagnostic_summary}.}
\examples{
set.seed(1)
y <- simulate_garch(300)
fit <- cgd_garch(y, q = 2, s = 1, lambda = 0.001)
cgd_diagnostic_summary(fit)
}
