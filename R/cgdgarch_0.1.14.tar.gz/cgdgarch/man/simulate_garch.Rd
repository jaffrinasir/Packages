\name{simulate_garch}
\alias{simulate_garch}
\title{Simulate a univariate ARCH/GARCH process}
\description{Simulates returns from an ARCH/GARCH recursion with user-specified coefficients and innovation generator.}
\usage{
simulate_garch(n, omega = 0.01, alpha = 0.1, beta = 0.8,
               innov = stats::rnorm, burnin = 200L,
               return_details = FALSE)
}
\arguments{
\item{n}{Number of returned observations after burn-in.}
\item{omega}{Positive variance intercept.}
\item{alpha}{Vector of non-negative ARCH coefficients; use \code{numeric(0)} for none.}
\item{beta}{Vector of non-negative GARCH coefficients; use \code{numeric(0)} for a pure ARCH process.}
\item{innov}{Function generating innovations with one integer argument.}
\item{burnin}{Number of burn-in observations.}
\item{return_details}{Logical; return latent variance and innovations in addition to returns.}
}
\details{The initial variance uses \eqn{\omega/(1-\sum\alpha_i-\sum\beta_j)} when the persistence is comfortably below one, with a protective fallback for near-integrated parameter choices. Simulation benchmarking is easier with \code{return_details = TRUE} because the true latent \eqn{\sigma_t^2} path is retained.}
\value{A numeric return vector, or a \code{cgd_garch_simulation} list containing \code{y}, \code{sigma2}, \code{innovations}, parameters, orders, and burn-in.}
\examples{
set.seed(1)
y <- simulate_garch(200)
sim <- simulate_garch(200, return_details = TRUE)
head(sim$y)
head(sim$sigma2)
}
