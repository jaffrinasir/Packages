\name{cgd_lambda_ic_path}
\alias{cgd_lambda_ic_path}
\alias{print.cgd_ic_path}
\alias{plot.cgd_ic_path}
\title{Information-criterion path over a lambda grid}
\description{
Fits \code{cgd_garch()} over a lambda grid and records information criteria, active-set size, log-likelihood, objective value, and convergence status. This object is designed for tuning reports and Shiny displays.
}
\usage{
cgd_lambda_ic_path(y, q = 1L, s = 1L, penalty = penalty_scad(),
                   lambda = NULL, lambda_min_ratio = 1e-4,
                   nlambda = 30L, grid_depth = NULL,
                   lambda_method = c("dyadic", "log"),
                   fit_unpenalized = TRUE,
                   warm_start = TRUE, ...)
\method{plot}{cgd_ic_path}(x, criteria = c("AIC", "BIC", "Hannan_Quinn"),
                          type = c("criteria", "coefficients"),
                          x_axis = c("log_lambda", "lambda"),
                          include_intercept = FALSE, col = NULL, lty = NULL,
                          lwd = 1.6, legend_pos = "topright", legend = TRUE, ...)
}
\arguments{
\item{y}{Numeric return series.}
\item{q, s}{Maximum ARCH and GARCH orders.}
\item{penalty}{Penalty object.}
\item{lambda}{Optional lambda vector. If \code{NULL}, \code{lambda_grid_cgd()} is used.}
\item{lambda_min_ratio, nlambda, grid_depth, lambda_method}{Arguments controlling automatic lambda-grid construction.}
\item{fit_unpenalized}{Logical; passed to \code{lambda_grid_cgd()} when \code{lambda} is \code{NULL}.}
\item{warm_start}{Logical; use the previous lambda solution as the starting value for the next fit.}
\item{x}{A fitted \code{cgd_ic_path} object.}
\item{criteria}{Information criteria to display when \code{type = "criteria"}.}
\item{type}{Plot type. \code{"criteria"} shows information-criterion profiles; \code{"coefficients"} shows the parameter solution path using the already fitted lambda sequence.}
\item{x_axis}{Horizontal-axis scale: \code{"log_lambda"} or \code{"lambda"}.}
\item{include_intercept}{Logical; include the unpenalized variance intercept \eqn{\omega} in a coefficient-path plot.}
\item{col, lty, lwd}{Optional line colours, line types, and line widths.}
\item{legend_pos}{Position passed to \code{legend()}.}
\item{legend}{Logical; draw the plot legend.}
\item{...}{Additional arguments passed to \code{cgd_garch()} by \code{cgd_lambda_ic_path()}, or to the base plotting function by the plot method.}
}
\value{An object of class \code{cgd_ic_path} with components \code{path}, \code{fits}, \code{coefficients}, \code{best}, \code{q}, \code{s}, \code{penalty}, and \code{lambda_grid}.}
\details{
The information-criterion plot uses matching colours and line types in the
plot and legend. The same fitted path can also be displayed as a penalization
solution path by calling \code{plot(x, type = "coefficients")}. This reuses
the fitted models stored in the object, so no additional estimation is
performed. Set \code{x_axis = "lambda"} to show the actual regularization
parameter on the horizontal axis; the BIC-selected value is marked
automatically.
}
\examples{
set.seed(1)
y <- simulate_garch(300)
ip <- cgd_lambda_ic_path(y, q = 2, s = 1, grid_depth = 5, max_iter = 80)
ip$best
plot(ip)
plot(ip, type = "coefficients", x_axis = "lambda")
}
