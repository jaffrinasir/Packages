\name{cv_cgd_garch}
\alias{cv_cgd_garch}
\alias{print.cgd_cv}
\alias{plot.cgd_cv}
\title{Rolling-origin cross-validation for penalized GARCH}
\description{
Evaluates a sequence of lambda values by time-ordered cross-validation. The folds are constructed as expanding training windows followed by short validation blocks, avoiding random shuffling of a time series.
}
\usage{
cv_cgd_garch(y, q = 1L, s = 1L, penalty = penalty_alasso(),
             lambda = NULL, nfolds = 5L, min_train = NULL,
             lambda_min_ratio = 1e-4, nlambda = 30L,
             grid_depth = NULL, lambda_method = c("dyadic", "log"),
             fit_unpenalized = TRUE, ...)
}
\arguments{
\item{y}{Numeric return series.}
\item{q, s}{Maximum ARCH and GARCH orders.}
\item{penalty}{Penalty object.}
\item{lambda}{Optional lambda vector. If \code{NULL}, an automatic grid is generated.}
\item{nfolds}{Number of validation blocks.}
\item{min_train}{Size of the first training window. Defaults to half the sample or at least 50 observations.}
\item{lambda_min_ratio, nlambda, grid_depth, lambda_method}{Arguments passed to \code{lambda_grid_cgd()} when \code{lambda} is \code{NULL}.}
\item{fit_unpenalized}{Logical; passed to \code{lambda_grid_cgd()} when \code{lambda} is \code{NULL}.}
\item{...}{Additional arguments passed to \code{cgd_garch()}.}
}
\details{
For each lambda, the model is fitted on an expanding historical window. One-step or block validation losses are approximated through the Gaussian quasi-likelihood contribution on the following validation block. The selected value \code{lambda.min} minimizes the mean validation loss.
}
\value{An object of class \code{cgd_cv} containing \code{lambda}, \code{cvm}, \code{cvse}, \code{lambda.min}, fold metadata, and optionally the automatic lambda-grid object.}
\examples{
set.seed(1)
y <- simulate_garch(250)
cv <- cv_cgd_garch(y, q = 2, s = 1, penalty = penalty_scad(),
                   grid_depth = 4, nfolds = 3, max_iter = 60,
                   fit_unpenalized = FALSE)
cv$lambda.min
plot(cv)
}
