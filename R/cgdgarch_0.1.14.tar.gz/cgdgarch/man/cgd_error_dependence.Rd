\name{cgd_error_dependence}
\alias{cgd_error_dependence}
\alias{plot_error_acf}
\alias{plot_error_pacf}
\title{ACF and PACF of squared standardized errors}
\description{
Computes and plots the ACF and PACF of squared standardized errors from a fitted \code{cgd_garch} model. These are useful for checking remaining volatility dependence after filtering.
}
\usage{
cgd_error_dependence(object, lag.max = NULL)

plot_error_acf(x, lag.max = NULL, ...)

plot_error_pacf(x, lag.max = NULL, ...)
}
\arguments{
\item{object}{A fitted \code{cgd_garch} object.}
\item{lag.max}{Maximum lag.}
\item{x}{A \code{cgd_garch} object or output from \code{cgd_error_dependence()}.}
\item{...}{Additional graphical arguments.}
}
\value{An object of class \code{cgd_error_dependence} with \code{acf} and \code{pacf} data frames.}
\examples{
set.seed(1)
y <- simulate_garch(300)
fit <- cgd_garch(y, q = 2, s = 1, lambda = 0.001)
ed <- cgd_error_dependence(fit, lag.max = 20)
head(ed$acf)
plot_error_acf(ed)
plot_error_pacf(ed)
}
