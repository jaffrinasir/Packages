\name{cgdgarch-package}
\alias{cgdgarch-package}
\alias{cgdgarch}
\docType{package}
\title{Sparse ARCH/GARCH estimation, tuning, diagnostics, and risk forecasts}
\description{
\pkg{cgdgarch} fits univariate ARCH and GARCH volatility models by coordinate-gradient descent with optional adaptive or nonconvex penalization. The package is designed for sparse lag-selection workflows in which users specify maximum ARCH/GARCH orders and tune a penalty to retain a parsimonious active set.
}
\details{
The package combines five layers of functionality:
\enumerate{
  \item \strong{Estimation.} \code{cgd_garch()} and \code{cgd_arch()} fit fixed-lambda models under a Gaussian quasi-likelihood with non-negative volatility parameters.
  \item \strong{Penalization.} Adaptive LASSO, SCAD, MCP, arctan, Laplace, and composite L1-Gaussian penalties are available through dedicated constructors.
  \item \strong{Tuning.} \code{lambda_grid_cgd()} builds data-dependent dyadic or logarithmic grids; \code{cgd_lambda_ic_path()}, \code{cv_cgd_garch()}, and \code{solution_path()} support information-criterion, cross-validation, and coefficient-path workflows.
  \item \strong{Diagnostics and visualization.} Conditional-variance traces, squared-error ACF/PACF, compact interpreted diagnostics, S3 plots, and a bundled Shiny dashboard are included.
  \item \strong{Risk and empirical context.} \code{cgd_var()} and \code{cgd_var_backtest()} provide Gaussian conditional VaR tools. \code{cgd_compare_garch()} compares a fixed-order unpenalized task with \pkg{rugarch} and \pkg{fGarch} when installed.
}

Repeated conditional-variance recursions, quasi-likelihood evaluation, score calculations, and diagonal curvature calculations are implemented in C++ through \pkg{Rcpp}. The public interface remains ordinary R/S3 code.

The current scope is deliberately focused: univariate ARCH/GARCH variance dynamics with Gaussian quasi-likelihood. Student-t/skewed innovations, asymmetric GARCH families, ARFIMA mean dynamics, and multivariate volatility models are not yet implemented.

The adaptive-LASSO CGD methodology underlying the package is developed in Nasir et al. (2025). The additional penalty families and software interface extend that computational framework, but users should not interpret approximate standard errors printed by the package as exact post-selection inference.
}
\section{Core workflow}{
A typical analysis is:
\preformatted{
pen <- penalty_scad()
lg <- lambda_grid_cgd(y, q = 5, s = 1, penalty = pen,
                      grid_depth = 10, method = "dyadic")
ip <- cgd_lambda_ic_path(y, q = 5, s = 1, penalty = pen,
                         lambda = lg$lambda)
fit <- ip$fits[[ip$best$index]]
summary(fit)
cgd_var(fit, level = c(0.95, 0.99), n.ahead = 5)
}
}
\section{Main user-facing functions}{
\describe{
  \item{\code{cgd_garch()}, \code{cgd_arch()}}{Penalized or unpenalized ARCH/GARCH estimation for a fixed lambda.}
  \item{\code{lambda_grid_cgd()}}{Automatic dyadic/logarithmic tuning grids.}
  \item{\code{cgd_lambda_ic_path()}}{Information-criterion path and BIC-selected fit.}
  \item{\code{cv_cgd_garch()}}{Time-ordered cross-validation for lambda.}
  \item{\code{solution_path()}}{Coefficient paths over lambda.}
  \item{\code{cgd_variance_trace()}, \code{cgd_error_dependence()}}{Variance and dependence diagnostics.}
  \item{\code{cgd_diagnostic_summary()}}{Compact interpreted diagnostic table.}
  \item{\code{cgd_var()}, \code{cgd_var_backtest()}}{Conditional Gaussian VaR and calibration checks.}
  \item{\code{cgd_compare_garch()}}{Empirical context against installed standard GARCH packages.}
  \item{\code{cgd_shiny_app()}}{Interactive package dashboard.}
}
}
\references{
Nasir, M. J. M., Khan, R. N., Nair, G., and Nur, D. (2025). Coordinate gradient descent algorithm in adaptive LASSO for pure ARCH and pure GARCH models. \emph{Computational Statistics}, 40, 3527--3561. \doi{10.1007/s00180-025-01642-1}.
}
\author{MUHAMMAD JAFFRI MOHD NASIR <jaffri.mn@umk.edu.my>; Gopalan Nair <gopalan.nair@uwa.edu.au>; Darfiana Nur <darfiana.nur@uwa.edu.au>; Ahmad Hakiim Jamaluddin <ahmadhakiim@upm.edu.my>}
