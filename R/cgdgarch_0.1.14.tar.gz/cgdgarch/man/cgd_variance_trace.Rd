\name{cgd_variance_trace}
\alias{cgd_variance_trace}
\alias{plot_variance_trace}
\title{Fitted and filtered conditional variance traces}
\description{
Creates Shiny-ready data and a base plot comparing the fitted conditional variance from a \code{cgd_garch} object with a forward-filtered variance trace using the final parameter vector.
}
\usage{
cgd_variance_trace(object, init = c("unconditional", "sample"))

plot_variance_trace(x, log_scale = FALSE, ...)
}
\arguments{
\item{object}{A fitted \code{cgd_garch} object.}
\item{init}{Initialisation for the filtering recursion.}
\item{x}{A \code{cgd_garch} object or output from \code{cgd_variance_trace()}.}
\item{log_scale}{Logical; plot log sigma squared.}
\item{...}{Additional arguments passed to plotting functions.}
}
\value{A data frame with \code{time}, \code{return}, \code{error2}, \code{fitted_sigma2}, \code{filtered_sigma2}, and \code{difference}.}
\examples{
set.seed(1)
y <- simulate_garch(300)
fit <- cgd_garch(y, q = 2, s = 1, lambda = 0.001)
vt <- cgd_variance_trace(fit)
head(vt)
plot_variance_trace(vt)
}
