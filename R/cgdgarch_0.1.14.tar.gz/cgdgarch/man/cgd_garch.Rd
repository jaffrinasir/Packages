\name{cgd_garch}
\alias{cgd_garch}
\alias{cgd_arch}
\title{Penalized ARCH/GARCH estimation by coordinate-gradient descent}
\description{
Fits ARCH(q) and GARCH(q,s) volatility models by minimizing a penalized Gaussian quasi-likelihood. The intercept is left unpenalized while ARCH and GARCH lag coefficients are regularized by adaptive LASSO, SCAD, MCP, arctan, Laplace, or composite L1-Gaussian penalties. Penalties with a nonzero slope at the origin can generate exact zeros; a purely smooth Gaussian component is primarily a shrinkage regularizer.
}
\usage{
cgd_garch(y, q = 1L, s = 1L, penalty = penalty_alasso(), lambda = 0.001,
          max_iter = 300L, tol = 1e-6, step_size = 1,
          armijo = 0.5, threshold = 1e-8, use_cpp = TRUE,
          start = NULL, verbose = FALSE)

cgd_arch(y, q = 1L, ...)
}
\arguments{
\item{y}{Numeric vector of returns. The mean is estimated and removed before fitting the variance recursion.}
\item{q}{Maximum ARCH order.}
\item{s}{Maximum GARCH order. Use \code{s = 0} for pure ARCH models.}
\item{penalty}{Penalty object created by \code{penalty_alasso()}, \code{penalty_scad()}, \code{penalty_mcp()}, \code{penalty_arctan()}, \code{penalty_laplace()}, or \code{penalty_clg()}.}
\item{lambda}{Non-negative tuning parameter. Use \code{lambda_grid_cgd()}, \code{cv_cgd_garch()}, or \code{cgd_lambda_ic_path()} to automate selection.}
\item{max_iter}{Maximum number of coordinate-gradient cycles.}
\item{tol}{Convergence tolerance based on maximum absolute parameter change.}
\item{step_size}{Initial step size used inside coordinate updates.}
\item{armijo}{Backtracking reduction factor.}
\item{threshold}{Values below this value are reported as zero.}
\item{use_cpp}{Logical; use compiled Rcpp routines when available.}
\item{start}{Optional starting vector of length \code{1 + q + s}.}
\item{verbose}{Logical; print progress information.}
\item{...}{Arguments passed from \code{cgd_arch()} to \code{cgd_garch()}.}
}
\details{
The fitted variance recursion is
\deqn{\sigma_t^2 = \omega + \sum_{i=1}^{q}\alpha_i y_{t-i}^2 + \sum_{j=1}^{s}\beta_j\sigma_{t-j}^2,}
with non-negative parameters. The penalized objective is the Gaussian quasi-likelihood plus a separable penalty on lag coefficients. The package stores fitted conditional variances, standardized residuals, model metadata, the active lag set, and diagnostics used by the console and Shiny reporting layers. Setting \code{lambda = 0} gives a fixed-order non-penalized reference fit. For an empirical context check against established fixed-order workflows, see \code{cgd_compare_garch()}.

The conditional mean is handled as a constant sample mean that is removed before the variance recursion is estimated. This is intentionally simpler than the richer ARMA mean specifications available in general-purpose GARCH packages.

The reported standard errors are approximate diagonal QMLE and diagonal sandwich screens. They are useful diagnostics, but they are not exact post-selection standard errors for nonconvex penalized GARCH models.
}
\value{
An object of class \code{cgd_garch}. Methods are available for \code{print()}, \code{summary()}, \code{coef()}, \code{fitted()}, \code{residuals()}, \code{predict()}, and \code{plot()}.
}
\examples{
set.seed(1)
y <- simulate_garch(400, omega = 0.02, alpha = c(0.12, 0, 0.08), beta = 0.75)
fit <- cgd_garch(y, q = 3, s = 1, penalty = penalty_scad(), lambda = 0.001)
print(fit)
coef(fit)
predict(fit, n.ahead = 5)
}
