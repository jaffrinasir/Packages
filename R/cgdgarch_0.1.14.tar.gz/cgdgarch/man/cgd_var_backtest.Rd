\name{cgd_var_backtest}
\alias{cgd_var_backtest}
\alias{print.cgd_var_backtest}
\alias{plot.cgd_var_backtest}
\title{Evaluate conditional Value-at-Risk coverage and exception dependence}
\description{
Evaluates Gaussian conditional VaR thresholds using exception counts, Kupiec unconditional coverage, Christoffersen exception-independence, and joint conditional-coverage likelihood-ratio diagnostics.
}
\usage{
cgd_var_backtest(object = NULL, level = 0.99, realized = NULL,
                 sigma = NULL, mu = NULL)

\method{print}{cgd_var_backtest}(x, ...)
\method{plot}{cgd_var_backtest}(x, ...)
}
\arguments{
\item{object}{Optional fitted \code{cgd_garch} object. When used alone, fitted in-sample variances are evaluated and the result is explicitly labelled an in-sample diagnostic.}
\item{level}{Single VaR confidence level.}
\item{realized}{Optional realized out-of-sample return sequence.}
\item{sigma}{Matching conditional standard-deviation forecasts.}
\item{mu}{Matching conditional mean forecasts or a scalar mean.}
\item{x}{A \code{cgd_var_backtest} object.}
\item{...}{Graphical arguments for the plot method or otherwise unused.}
}
\details{
An exception occurs when a realized return falls below its VaR return threshold. The Kupiec likelihood-ratio statistic tests whether the unconditional exception frequency is compatible with the nominal tail probability. The Christoffersen independence statistic tests whether exceptions exhibit first-order dependence, and the conditional-coverage statistic combines the two components.

When only \code{object} is supplied, the function evaluates fitted in-sample conditional variances. This is useful for calibration screening but is \emph{not} a genuine forecast backtest. For predictive validation, supply out-of-sample \code{realized}, \code{sigma}, and optionally \code{mu} generated without using the future observations being evaluated.

Very high confidence levels require long evaluation samples because only a small number of exceptions are expected. Failure to reject a coverage test in a short sample should therefore not be interpreted as proof that a tail-risk model is correct.
}
\value{An object of class \code{cgd_var_backtest} containing exception frequencies, likelihood-ratio tests, transition counts, and the realized/threshold series.}
\references{
Kupiec, P. H. (1995). Techniques for verifying the accuracy of risk measurement models. \emph{The Journal of Derivatives}, 3(2), 73--84.

Christoffersen, P. F. (1998). Evaluating interval forecasts. \emph{International Economic Review}, 39(4), 841--862.
}
\examples{
set.seed(13)
y <- simulate_garch(400)
fit <- cgd_garch(y, q = 1, s = 1, lambda = 0, max_iter = 30)
bt <- cgd_var_backtest(fit, level = 0.95)
bt
plot(bt)
}
