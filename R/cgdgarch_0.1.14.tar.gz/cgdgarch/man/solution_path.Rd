\name{solution_path}
\alias{solution_path}
\alias{plot.cgd_path}
\title{Coefficient solution path over lambda values}
\description{
Fits \code{cgd_garch()} over a decreasing lambda sequence and records the coefficient trajectory. Use \code{cgd_lambda_ic_path()} instead when the main interest is information-criterion tuning.
}
\usage{
solution_path(y, q = 1L, s = 1L, penalty = penalty_scad(),
              lambda = NULL, lambda_min_ratio = 1e-4,
              nlambda = 30L, grid_depth = NULL,
              lambda_method = c("dyadic", "log"),
              fit_unpenalized = TRUE, warm_start = TRUE, ...)
\method{plot}{cgd_path}(x, x_axis = c("log_lambda", "lambda"),
                       include_intercept = TRUE, selected_lambda = NULL,
                       col = NULL, lty = NULL, lwd = 1.6,
                       legend_pos = "topright", legend = TRUE, ...)
}
\arguments{
\item{y}{Numeric return series.}
\item{q, s}{Maximum ARCH and GARCH orders.}
\item{penalty}{Penalty object.}
\item{lambda}{Optional lambda vector. If \code{NULL}, an automatic grid is generated.}
\item{lambda_min_ratio, nlambda, grid_depth, lambda_method}{Arguments controlling automatic lambda-grid construction.}
\item{fit_unpenalized}{Logical; passed to \code{lambda_grid_cgd()} when \code{lambda} is \code{NULL}.}
\item{warm_start}{Logical; use each solution as the next starting value.}
\item{x}{A fitted \code{cgd_path} object.}
\item{x_axis}{Horizontal-axis scale for the solution-path plot: \code{"log_lambda"} or \code{"lambda"}.}
\item{include_intercept}{Logical; include the unpenalized variance intercept \eqn{\omega} in the path plot.}
\item{selected_lambda}{Optional non-negative lambda value to mark with a vertical line.}
\item{col, lty, lwd}{Optional line colours, line types, and line widths for parameter paths.}
\item{legend_pos}{Position passed to \code{legend()}.}
\item{legend}{Logical; draw the parameter legend.}
\item{...}{Additional arguments passed to \code{cgd_garch()} by \code{solution_path()}, or to the base plotting function by the plot method.}
}
\value{An object of class \code{cgd_path} containing lambda values, coefficient matrix, fitted objects, and metadata.}
\details{
The S3 plot method displays the model-parameter solution path over the tuning
sequence. By default the horizontal axis is \code{log(lambda)}. Set
\code{x_axis = "lambda"} to display coefficient estimates against the actual
regularization parameter. Use \code{include_intercept = FALSE} to focus on
the penalized ARCH/GARCH lag coefficients, and \code{selected_lambda} to add
a vertical reference line for a chosen tuning value.
}
\examples{
set.seed(1)
y <- simulate_garch(250)
path <- solution_path(y, q = 2, s = 1, grid_depth = 4, max_iter = 60,
                      fit_unpenalized = FALSE)
plot(path)
plot(path, x_axis = "lambda", include_intercept = FALSE)
}
