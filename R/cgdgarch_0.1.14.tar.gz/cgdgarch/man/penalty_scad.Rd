\name{penalty_scad}
\alias{penalty_alasso}
\alias{penalty_scad}
\alias{penalty_mcp}
\alias{penalty_arctan}
\alias{penalty_laplace}
\alias{penalty_clg}
\title{Penalty specifications for penalized ARCH/GARCH estimation}
\description{
Construct penalty objects used by \code{cgd_garch()}, automatic lambda-grid construction, cross-validation, and solution-path functions. The constructors separate penalty-specific shape parameters from the main tuning parameter \code{lambda}.
}
\usage{
penalty_alasso(weights = NULL, gamma = 2)
penalty_scad(a = 3.7)
penalty_mcp(gamma = 3)
penalty_arctan(scale = 0.1)
penalty_laplace(scale = 0.5)
penalty_clg(alpha = 0.7, kappa = 2)
}
\arguments{
\item{weights}{Optional adaptive LASSO weights of length \code{q + s}. If omitted, the package can construct weights from a preliminary fit.}
\item{gamma}{For \code{penalty_alasso()}, the exponent in the adaptive weights; for \code{penalty_mcp()}, the MCP concavity parameter.}
\item{a}{SCAD shape parameter, greater than 2. The conventional default is 3.7.}
\item{scale}{Positive transition scale. For \code{penalty_arctan()}, the implemented normalized penalty is \eqn{(2/\pi)\arctan(t/\mathrm{scale})}. For \code{penalty_laplace()}, it is \eqn{1-\exp(-t/\mathrm{scale})}.}
\item{alpha}{Mixing weight in \eqn{[0,1]} for the L1 component of the composite L1-Gaussian penalty.}
\item{kappa}{Positive shape parameter for the Gaussian component \eqn{1-\exp(-\kappa t^2)}.}
}
\details{
The adaptive LASSO uses a weighted L1 penalty and is convex after the weights are fixed. The ARCH/GARCH adaptive-LASSO foundation and its coordinate-gradient implementation are described by Nasir et al. (2025), building on the adaptive weighting principle of Zou (2006).

SCAD (Fan and Li, 2001) and MCP (Zhang, 2010) are nonconvex sparsity penalties whose local slopes decrease as a coefficient becomes larger, thereby reducing shrinkage of sufficiently strong signals relative to L1 penalization.

The arctan and Laplace penalties are bounded nonconvex alternatives. Both constructors use the argument \code{scale}, so their software interfaces match their mathematical role. The implemented forms are \eqn{(2/\pi)\arctan(t/\mathrm{scale})} and \eqn{1-\exp(-t/\mathrm{scale})}. Smaller scales make the penalty approach its upper bound more quickly; larger scales extend the region in which the penalty is approximately linear. These are reparameterizations of forms discussed by Vettam and John (2022), with earlier formulations due to Wang and Zhu (2016) for arctan regularization and Trzasko and Manduca (2009) for the Laplace-type penalty.

The composite L1-Gaussian penalty is \eqn{\alpha t + (1-\alpha)(1-\exp(-\kappa t^2))}. The L1 component supplies a nonzero origin slope when \eqn{\alpha>0}, while the Gaussian component is smooth at the origin and provides bounded nonconvex shrinkage away from zero. With \eqn{\alpha=0}, the penalty is smooth at the origin and should be viewed primarily as a shrinkage regularizer rather than an exact subset-selection penalty.
}
\value{An object of class \code{cgd_penalty}.}
\references{
Fan, J. and Li, R. (2001). Variable selection via nonconcave penalized likelihood and its oracle properties. \emph{Journal of the American Statistical Association}, 96, 1348--1360.

Nasir, M. J. M., Khan, R. N., Nair, G. and Nur, D. (2025). Coordinate gradient descent algorithm in adaptive LASSO for pure ARCH and pure GARCH models. \emph{Computational Statistics}, 40, 3527--3561.

Vettam, S. and John, M. (2022). On two recent nonconvex penalties for regularization in machine learning. \emph{Results in Applied Mathematics}, 14, 100256.

Zhang, C.-H. (2010). Nearly unbiased variable selection under minimax concave penalty. \emph{The Annals of Statistics}, 38, 894--942.

Zou, H. (2006). The adaptive LASSO and its oracle properties. \emph{Journal of the American Statistical Association}, 101, 1418--1429.
}
\examples{
penalty_alasso(gamma = 2)
penalty_scad(a = 3.7)
penalty_mcp(gamma = 3)
penalty_arctan(scale = 0.1)
penalty_laplace(scale = 0.5)
penalty_clg(alpha = 0.7, kappa = 2)
}
