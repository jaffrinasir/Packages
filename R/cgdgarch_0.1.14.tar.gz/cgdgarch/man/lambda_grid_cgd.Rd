\name{lambda_grid_cgd}
\alias{lambda_grid_cgd}
\title{Construct data-dependent dyadic or logarithmic lambda grids}
\description{
Builds a tuning path for penalized ARCH/GARCH estimation by estimating an upper scale \code{lambda_max}, deriving \code{lambda_min}, and returning either a dyadic or logarithmically spaced grid. The same utility is used internally by information-criterion paths, solution paths, and cross-validation when no explicit lambda vector is supplied.
}
\usage{
lambda_grid_cgd(y, q = 1L, s = 1L, penalty = penalty_alasso(),
                lambda_max = NULL, lambda_min = NULL,
                lambda_min_ratio = 1e-4, nlambda = 30L,
                grid_depth = NULL, method = c("dyadic", "log"),
                gamma = NULL, fit_unpenalized = TRUE, ...)
}
\arguments{
\item{y}{Numeric return series.}
\item{q}{Maximum ARCH order.}
\item{s}{Maximum GARCH order.}
\item{penalty}{Penalty specification created by a \code{penalty_*()} constructor.}
\item{lambda_max}{Optional positive upper tuning scale. If omitted, it is estimated from the null-model score and the penalty slope at the origin.}
\item{lambda_min}{Optional positive lower tuning value, smaller than \code{lambda_max}.}
\item{grid_depth}{Optional depth of the dyadic halving path. Larger values explore weaker penalization.}
\item{nlambda}{Optional number of grid values. For logarithmic grids this controls the path resolution; for dyadic grids the implementation may densify the basic halving sequence.}
\item{lambda_min_ratio}{Positive ratio \eqn{\lambda_{min}/\lambda_{max}} used when \code{lambda_min} is omitted and a direct dyadic depth does not determine the minimum.}
\item{method}{Either \code{"dyadic"} or \code{"log"}.}
\item{gamma}{Optional override for the adaptive-LASSO weight exponent when the selected penalty is adaptive LASSO.}
\item{fit_unpenalized}{Logical; for adaptive LASSO, obtain a preliminary unpenalized fit before forming adaptive weights when feasible.}
\item{...}{Additional arguments used by the preliminary fitting step.}
}
\details{
A dyadic grid starts at \eqn{\lambda_{max}} and repeatedly halves the tuning parameter,
\deqn{\lambda_k = \lambda_{max}/2^k.}
The package can insert intermediate values to obtain a denser path while retaining the interpretable halving structure. This construction follows the practical shrinkage-grid strategy used in the adaptive-LASSO ARCH/GARCH work of Nasir et al. (2025).

A logarithmic grid places candidate values evenly on the log scale between \eqn{\lambda_{max}} and \eqn{\lambda_{min}},
\deqn{\lambda_m = \exp\{\log(\lambda_{max}) + u_m[\log(\lambda_{min})-\log(\lambda_{max})]\},}
where \eqn{u_m} is equally spaced from zero to one. Log grids provide smooth coverage across several orders of magnitude.

The data-dependent upper scale is based on the null-model score and the local penalty slope at the origin. For penalties with a nonzero origin slope, \code{lambda_max} is intended to be near the point at which all penalized lag coefficients are excluded. For a purely smooth composite L1-Gaussian penalty with \code{alpha = 0}, there is no nonzero origin slope, so \code{lambda_max} is a shrinkage-path scale rather than a strict all-zero threshold.

A practical strategy is to use a dyadic path for fast exploration, then use a denser logarithmic path if the selected information-criterion minimum lies near an edge of the initial grid or if the coefficient path changes too coarsely.
}
\value{
An object of class \code{cgd_lambda_grid} containing at least \code{lambda}, \code{lambda_max}, \code{lambda_min}, \code{grid_depth}, the grid method, and penalty metadata.
}
\references{
Nasir, M. J. M., Khan, R. N., Nair, G. and Nur, D. (2025). Coordinate gradient descent algorithm in adaptive LASSO for pure ARCH and pure GARCH models. \emph{Computational Statistics}, 40, 3527--3561.
}
\examples{
set.seed(1)
y <- simulate_garch(300)

lg_d <- lambda_grid_cgd(y, q = 2, s = 1, penalty = penalty_scad(),
                        grid_depth = 6, method = "dyadic",
                        fit_unpenalized = FALSE)
lg_d$lambda

lg_l <- lambda_grid_cgd(y, q = 2, s = 1, penalty = penalty_scad(),
                        nlambda = 30, lambda_min_ratio = 1e-4,
                        method = "log", fit_unpenalized = FALSE)
head(lg_l$lambda)
}
