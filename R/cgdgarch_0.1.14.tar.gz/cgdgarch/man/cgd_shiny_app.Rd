\name{cgd_shiny_app}
\alias{cgd_shiny_app}
\title{Launch the bundled cgdgarch Shiny dashboard}
\description{
Launches a Shiny dashboard for fitting \code{cgdgarch} models and visualising lambda information-criterion paths, fitted and filtered variance traces, ACF/PACF of squared standardized errors, interpreted diagnostics, and Gaussian conditional Value-at-Risk output.
}
\usage{
cgd_shiny_app(...)
}
\arguments{
\item{...}{Additional arguments passed to \code{shiny::runApp()}.}
}
\details{
The dashboard is a graphical layer over exported package functions rather than a separate estimator. It exposes the lambda path and BIC choice, fitted-versus-filtered conditional variance, squared-error ACF/PACF, diagnostic interpretations, and VaR forecasts/backtesting. Results shown in the app can therefore be reproduced directly with the corresponding R functions.
}
\value{The result of \code{shiny::runApp()}.}
\examples{
\dontrun{
install.packages("shiny")
cgd_shiny_app()
}
}
