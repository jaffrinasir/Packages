# cgdgarch 0.1.14

- Fixed `plot.cgd_ic_path()` so information-criterion legend keys use the same colours and line types as the plotted AIC, BIC, Hannan-Quinn, and optional Shibata curves.
- Expanded the solution-path plotting interface. `plot.cgd_path()` now supports either `log(lambda)` or the actual `lambda` value on the horizontal axis, optional exclusion of the unpenalized intercept, coloured/typed parameter trajectories, and an optional selected-lambda reference line.
- Added a coefficient-path view to `plot.cgd_ic_path()` through `type = "coefficients"`. The plot reuses the models already fitted by `cgd_lambda_ic_path()` and automatically marks the BIC-selected lambda.
- `cgd_lambda_ic_path()` now stores the coefficient matrix for the fitted lambda sequence, making the parameter path directly accessible without refitting.
- Added tests and documentation for the enhanced information-criterion and penalization-path plots.

# cgdgarch 0.1.13

- Fixed `cgd_compare_garch()` benchmark extraction for current `rugarch` and `fGarch` S4 fit objects.
- Benchmark extractors now prefer the documented fitted-object slots (`rugarch` fit slot and `fGarch` `sigma.t`/fit slots) before S4 method dispatch.
- Added a `status` table to comparison objects so missing packages, fit failures, coefficient-extraction failures, and sigma-extraction failures are visible instead of being silently represented only by `NA`.
- Added `strict = TRUE/FALSE` to `cgd_compare_garch()`. With `strict = TRUE`, requested external benchmarks must complete successfully; otherwise the function stops with an informative error.
- Strengthened optional benchmark tests to require finite coefficients and conditional-variance metrics when `rugarch` or `fGarch` is installed.

# cgdgarch 0.1.12

- Renamed the arctan and Laplace constructor arguments to a common `scale` argument: `penalty_arctan(scale = ...)` and `penalty_laplace(scale = ...)`.
- Updated the internal penalty objects to store `scale`, removing the ambiguous arctan `gamma` and Laplace `eps` field names.
- Clarified how the positive transition scale controls each bounded penalty and updated the article, help pages, README, vignette, and tests.

# cgdgarch 0.1.11

- Documentation-only release focused on the R Journal article.
- Added result-specific interpretation of the two simulated sparse-model fits, information-criterion paths, variance traces, residual diagnostics, fixed-order package comparisons, DAX results, and VaR calibration output.
- Reworked article tables for shorter labels and more compact typography, and reduced figure dimensions to improve page balance.
- Replaced verbose console output and long code listings in result sections with compact publication tables while retaining reproducible code in the R Markdown source.
- No change to CGD estimation, Rcpp routines, penalty definitions, lambda-grid construction, diagnostics, comparison calculations, forecasting, simulation, or VaR methodology.

# cgdgarch 0.1.10

- Fixed `cgd_compare_garch()` for `fGarch` S4 `fGARCH` objects. The comparison no longer calls `stats::coef()` directly on an S4 object, which could fall through to `coef.default()` and fail with `$ operator not defined for this S4 class`.
- Added guarded `fGarch` extractors: coefficients use the registered S4 `coef` method with a read-only `@fit` fallback, while conditional standard deviations use the documented `@sigma.t` slot with `volatility()` fallback.
- Optional `fGarch` extraction failures are recorded in comparison notes instead of aborting the R Journal render.
- No change to CGD estimation, penalty definitions, lambda-grid construction, diagnostics, forecasting, simulation, or VaR calculations.

# cgdgarch 0.1.9

- Fixed `cgd_compare_garch()` for `rugarch` S4 fit objects. The comparison no longer calls `stats::sigma()` on a `uGARCHfit`, which could fall through to `sigma.default()` and fail with `$ operator not defined for this S4 class`.
- Added robust `rugarch` extractors for conditional sigma, coefficients, and convergence using registered S4 methods with a guarded fallback.
- Optional cross-package comparisons now record extractor failures in notes instead of aborting the entire R Journal render.
- No change to CGD estimation, penalty definitions, lambda-grid construction, diagnostics, forecasting, or VaR calculations.

# cgdgarch 0.1.8

- Fixed infinite recursion in `print.cgd_diagnostic_summary()`. The method now explicitly calls `print.data.frame()` on a plain data-frame view of the diagnostic object.
- Updated the R Journal diagnostic-summary chunk to render the diagnostic table explicitly rather than relying on S3 auto-printing.
- No statistical estimation formulas or fitting algorithms were changed in this maintenance release.

# cgdgarch 0.1.7

## Package and documentation

- Expanded package-level documentation, README, examples, and method descriptions.
- Added a citation file for the published CGD/adaptive-LASSO ARCH/GARCH methodology.
- Added an empirical fixed-order comparison helper for `cgdgarch`, `rugarch`, and `fGarch`.
- Extended `simulate_garch()` with `return_details = TRUE` to return latent conditional variances for simulation benchmarking.
- Updated the R Journal article with readable wrapped tables of core functions, penalty families, and workflow positioning.
- Compressed the statistical-model section and directs readers to Nasir et al. (2025) for the full adaptive-LASSO CGD derivation, assumptions, algorithms, and simulation evidence.

## Value-at-Risk

- Added `cgd_var()` for Gaussian conditional VaR forecasts at one or more confidence levels and horizons.
- Added `cgd_var_backtest()` with Kupiec unconditional-coverage, Christoffersen independence, and conditional-coverage diagnostics.
- Added VaR output to the bundled Shiny dashboard.

## Empirical context

- Added `cgd_compare_garch()` to compare fixed-order, unpenalized fits against `rugarch` and `fGarch` when installed.
- Added variance-trace agreement measures against known simulated variance when `true_sigma2` is supplied.
- Aligned the fixed-order comparison to common sample-mean centering across engines.
- Corrected the Shibata information-criterion calculation so it is no longer identical to AIC.
- Added a VaR calibration plot method and dyadic/logarithmic grid controls to the Shiny dashboard.

# cgdgarch 0.1.6

- Added Gopalan Nair, Darfiana Nur, and Ahmad Hakiim Jamaluddin as package contributors and article collaborators.

# cgdgarch 0.1.5

- Expanded documentation and Shiny-ready diagnostics.
- Added information-criterion lambda paths, fitted/filtered variance traces, squared-error ACF/PACF, and interpreted diagnostic summaries.

# cgdgarch 0.1.4

- Redesigned console reporting to avoid visual imitation of other GARCH packages.
