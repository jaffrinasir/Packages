# Cover letter

Dear Editors,

Please find attached the draft R Journal article for the development package `cgdgarch`, authored by MUHAMMAD JAFFRI MOHD NASIR, Gopalan Nair, Darfiana Nur, and Ahmad Hakiim Jamaluddin.

The manuscript focuses on the software contribution: penalized ARCH/GARCH estimation by coordinate-gradient descent, Rcpp acceleration, adaptive and nonconvex penalty families, automated dyadic/logarithmic lambda paths, diagnostics and Shiny visualization, reproducible empirical comparison with established fixed-order GARCH workflows, and Gaussian conditional Value-at-Risk utilities. The statistical-model section is intentionally concise and directs readers to the published methodological paper by Nasir et al. (2025) for the detailed CGD derivations, adaptive-LASSO theory, and simulation evidence.

The package is currently provided as a development source package. Before formal submission, we will complete local `R CMD check`, reproducibility checks, and the R Journal `rjtools` checks, and update package-availability statements as appropriate.

Sincerely,

MUHAMMAD JAFFRI MOHD NASIR
