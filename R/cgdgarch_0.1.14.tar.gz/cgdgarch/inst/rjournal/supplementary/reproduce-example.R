library(cgdgarch)

# Two article examples
set.seed(123456)
x <- simulate_garch(n = 2400, omega = 1.5,
                    alpha = c(0.1, 0, 0.2, 0, 0, 0.5),
                    beta = numeric(0))
set.seed(123123)
y <- simulate_garch(n = 2400, omega = 1,
                    alpha = c(0.1, 0, 0.1), beta = 0.75)

lgx <- lambda_grid_cgd(x, q = 6, s = 0, penalty = penalty_mcp(gamma = 2.5),
                       grid_depth = 30, fit_unpenalized = FALSE)
lgy <- lambda_grid_cgd(y, q = 3, s = 1, penalty = penalty_mcp(gamma = 2.5),
                       grid_depth = 30, fit_unpenalized = FALSE)

ipx <- cgd_lambda_ic_path(x, q = 6, s = 0, penalty = penalty_mcp(gamma = 2.5),
                          lambda = lgx$lambda, max_iter = 500)
ipy <- cgd_lambda_ic_path(y, q = 3, s = 1, penalty = penalty_mcp(gamma = 2.5),
                          lambda = lgy$lambda, max_iter = 500)
fitx <- ipx$fits[[ipx$best$index]]
fity <- ipy$fits[[ipy$best$index]]

# Diagnostics and VaR
plot_variance_trace(fity)
ed <- cgd_error_dependence(fity, lag.max = 24)
plot_error_acf(ed)
plot_error_pacf(ed)
cgd_diagnostic_summary(fity)
cgd_var(fity, level = c(0.95, 0.99), n.ahead = 5)
bt <- cgd_var_backtest(fity, level = 0.99)
print(bt)

# Fixed-order empirical context
set.seed(202607)
sim_cmp <- simulate_garch(n = 1200, omega = 0.02, alpha = 0.10, beta = 0.85,
                           return_details = TRUE)
cmp <- cgd_compare_garch(sim_cmp$y, q = 1, s = 1,
                         true_sigma2 = sim_cmp$sigma2, max_iter = 500)
print(cmp)

# Real-data fixed-order context
dax_ret <- 100 * diff(log(EuStockMarkets[, "DAX"]))
cmp_dax <- cgd_compare_garch(dax_ret, q = 1, s = 1, max_iter = 500)
print(cmp_dax)
