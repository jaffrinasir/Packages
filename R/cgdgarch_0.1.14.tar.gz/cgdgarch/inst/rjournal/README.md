# R Journal draft for cgdgarch 0.1.14

This folder contains the reproducible R Journal article source accompanying the development version of `cgdgarch`.

The arctan and Laplace constructors now use a common transition-scale API:

```r
penalty_arctan(scale = 0.1)
penalty_laplace(scale = 0.5)
```

For a standalone submission bundle, keep `cgdgarch-RJournal.Rmd` and `RJreferences.bib` in the same directory and render with:

```r
rmarkdown::render(
  "cgdgarch-RJournal.Rmd",
  output_format = "rjtools::rjournal_article",
  clean = FALSE
)
```

The package must still pass local `R CMD check`, and the article must be rendered and checked with `rjtools` before submission.
