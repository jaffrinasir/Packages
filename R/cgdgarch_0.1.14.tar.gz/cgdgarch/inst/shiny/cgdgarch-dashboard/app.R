# cgdgarch-dashboard: compact Shiny interface for cgdgarch diagnostics

if (!requireNamespace("shiny", quietly = TRUE)) {
  stop("This app requires the 'shiny' package.", call. = FALSE)
}

library(shiny)

penalty_from_input <- function(name) {
  switch(name,
    alasso = cgdgarch::penalty_alasso(),
    scad = cgdgarch::penalty_scad(),
    mcp = cgdgarch::penalty_mcp(),
    arctan = cgdgarch::penalty_arctan(),
    laplace = cgdgarch::penalty_laplace(),
    clg = cgdgarch::penalty_clg(),
    cgdgarch::penalty_scad()
  )
}

numeric_columns <- function(dat) {
  names(dat)[vapply(dat, is.numeric, logical(1))]
}

transform_series <- function(x, transform) {
  x <- as.numeric(x)
  x <- x[is.finite(x)]
  if (transform == "log_return") {
    x <- x[x > 0]
    x <- diff(log(x))
  } else if (transform == "simple_return") {
    x <- x[x > 0]
    x <- diff(x) / head(x, -1L)
  } else if (transform == "difference") {
    x <- diff(x)
  }
  x[is.finite(x)]
}

ui <- fluidPage(
  titlePanel("cgdgarch dashboard"),
  sidebarLayout(
    sidebarPanel(
      fileInput("file", "Optional CSV file", accept = c(".csv")),
      uiOutput("column_ui"),
      selectInput("transform", "Input transformation",
                  choices = c("Use as returns" = "none",
                              "Log returns from price" = "log_return",
                              "Simple returns from price" = "simple_return",
                              "First difference" = "difference")),
      numericInput("q", "Maximum ARCH order q", value = 3, min = 0, step = 1),
      numericInput("s", "Maximum GARCH order s", value = 1, min = 0, step = 1),
      selectInput("penalty", "Penalty", choices = c("SCAD" = "scad", "MCP" = "mcp",
                                                    "adaptive LASSO" = "alasso", "arctan" = "arctan",
                                                    "Laplace" = "laplace", "Composite L1-Gaussian" = "clg")),
      selectInput("lambda_method", "Lambda grid", choices = c("Dyadic" = "dyadic", "Logarithmic" = "log")),
      numericInput("grid_depth", "Dyadic grid depth", value = 7, min = 2, max = 30, step = 1),
      numericInput("nlambda", "Log-grid points", value = 30, min = 5, max = 150, step = 5),
      numericInput("max_iter", "Max CGD cycles", value = 120, min = 20, max = 1000, step = 20),
      selectInput("var_level", "VaR confidence level", choices = c("95%" = 0.95, "99%" = 0.99), selected = 0.99),
      actionButton("run", "Run CGD path", class = "btn-primary"),
      width = 3
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Lambda path", plotOutput("lambda_plot", height = 430), tableOutput("best_lambda")),
        tabPanel("Variance trace", plotOutput("variance_plot", height = 430), tableOutput("variance_head")),
        tabPanel("error^2 ACF", plotOutput("acf_plot", height = 430), tableOutput("acf_head")),
        tabPanel("error^2 PACF", plotOutput("pacf_plot", height = 430), tableOutput("pacf_head")),
        tabPanel("Diagnostics", tableOutput("diag_table"), verbatimTextOutput("fit_print")),
        tabPanel("Value-at-Risk",
                 tableOutput("var_forecast"),
                 verbatimTextOutput("var_summary"),
                 plotOutput("var_plot", height = 380),
                 tableOutput("var_backtest"))
      ),
      width = 9
    )
  )
)

server <- function(input, output, session) {
  raw_data <- reactive({
    if (is.null(input$file)) {
      set.seed(123)
      return(data.frame(default_returns = cgdgarch::simulate_garch(
        n = 700, omega = 0.02, alpha = c(0.12, 0, 0.06), beta = 0.78)))
    }
    utils::read.csv(input$file$datapath, stringsAsFactors = FALSE)
  })

  output$column_ui <- renderUI({
    cols <- numeric_columns(raw_data())
    if (!length(cols)) return(helpText("No numeric column detected."))
    selectInput("column", "Numeric column", choices = cols, selected = cols[1L])
  })

  series <- reactive({
    dat <- raw_data()
    cols <- numeric_columns(dat)
    req(length(cols) > 0)
    col <- input$column
    if (is.null(col) || !col %in% names(dat)) col <- cols[1L]
    y <- transform_series(dat[[col]], input$transform)
    validate(need(length(y) >= 80, "The selected series must provide at least 80 finite observations after transformation."))
    y
  })

  result <- eventReactive(input$run, {
    y <- series()
    q <- as.integer(input$q)
    s <- as.integer(input$s)
    validate(need(q + s > 0, "At least one of q and s must be positive."))
    pen <- penalty_from_input(input$penalty)
    path <- cgdgarch::cgd_lambda_ic_path(
      y = y, q = q, s = s, penalty = pen,
      grid_depth = as.integer(input$grid_depth),
      nlambda = as.integer(input$nlambda),
      lambda_method = input$lambda_method,
      max_iter = as.integer(input$max_iter),
      fit_unpenalized = FALSE
    )
    fit <- path$fits[[path$best$index]]
    list(path = path, fit = fit,
         trace = cgdgarch::cgd_variance_trace(fit),
         dep = cgdgarch::cgd_error_dependence(fit),
         diag = cgdgarch::cgd_diagnostic_summary(fit),
         var = cgdgarch::cgd_var(fit, level = as.numeric(input$var_level), n.ahead = 10),
         var_bt = cgdgarch::cgd_var_backtest(fit, level = as.numeric(input$var_level)))
  }, ignoreInit = FALSE)

  output$lambda_plot <- renderPlot({
    plot(result()$path)
  })

  output$best_lambda <- renderTable({
    result()$path$best
  }, digits = 6)

  output$variance_plot <- renderPlot({
    cgdgarch::plot_variance_trace(result()$fit)
  })

  output$variance_head <- renderTable({
    utils::head(result()$trace, 8)
  }, digits = 6)

  output$acf_plot <- renderPlot({
    cgdgarch::plot_error_acf(result()$dep)
  })

  output$acf_head <- renderTable({
    utils::head(result()$dep$acf, 12)
  }, digits = 5)

  output$pacf_plot <- renderPlot({
    cgdgarch::plot_error_pacf(result()$dep)
  })

  output$pacf_head <- renderTable({
    utils::head(result()$dep$pacf, 12)
  }, digits = 5)

  output$diag_table <- renderTable({
    result()$diag
  }, digits = 5)

  output$fit_print <- renderPrint({
    print(result()$fit)
  })

  output$var_forecast <- renderTable({
    result()$var
  }, digits = 6)


  output$var_summary <- renderPrint({
    bt <- result()$var_bt
    cat("Evaluation mode:", bt$mode, "\n")
    cat("Confidence level:", 100 * bt$level, "%\n")
    cat("Exceptions:", bt$exceptions, "of", bt$n,
        "| observed rate =", signif(bt$exception_rate, 4),
        "| nominal rate =", signif(bt$expected_rate, 4), "\n")
    if (identical(bt$mode, "in-sample diagnostic")) {
      cat("Interpretation: calibration screen only; use out-of-sample one-step forecasts for predictive VaR validation.\n")
    }
  })

  output$var_plot <- renderPlot({
    bt <- result()$var_bt
    ss <- bt$series
    graphics::plot(ss$realized, type = "l", xlab = "Effective observation", ylab = "Return",
                   main = paste0(round(100 * bt$level), "% Gaussian conditional VaR diagnostic"))
    graphics::lines(ss$VaR_return_threshold, lty = 2, lwd = 1.5)
    hit <- which(ss$exception == 1L)
    if (length(hit)) graphics::points(hit, ss$realized[hit], pch = 19)
    graphics::legend("bottomleft", legend = c("realized return", "VaR threshold", "exception"),
                     lty = c(1, 2, NA), pch = c(NA, NA, 19), bty = "n")
  })

  output$var_backtest <- renderTable({
    result()$var_bt$tests
  }, digits = 6)

}

shinyApp(ui, server)
