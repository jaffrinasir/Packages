#include <Rcpp.h>
using namespace Rcpp;

static inline double cgd_safe_pos(double x) {
  const double eps = 1e-12;
  return (R_finite(x) && x > eps) ? x : eps;
}

// Fast conditional variance recursion for ARCH(q)-GARCH(s).
NumericVector cgdgarch_sigma2_cpp(NumericVector err2, NumericVector par, int q, int s) {
  const int n = err2.size();
  const int h = std::max(q, s);
  const int p = 1 + q + s;
  if (par.size() != p) stop("Length of `par` must be 1 + q + s.");
  if (n < 1) return NumericVector(0);

  NumericVector err2pad(n + h);
  NumericVector sigpad(n + h);
  NumericVector sigma2(n);

  for (int t = 0; t < n; ++t) err2pad[t + h] = R_finite(err2[t]) ? err2[t] : 0.0;

  for (int t = 0; t < n; ++t) {
    double v = par[0];
    for (int i = 1; i <= q; ++i) v += par[i] * err2pad[t + h - i];
    for (int j = 1; j <= s; ++j) v += par[q + j] * sigpad[t + h - j];
    v = cgd_safe_pos(v);
    sigpad[t + h] = v;
    sigma2[t] = v;
  }

  return sigma2;
}

// Score and diagonal information for the mean Gaussian quasi-likelihood.
List cgdgarch_score_diag_cpp(NumericVector err2, NumericVector par, int q, int s) {
  const int n = err2.size();
  const int h = std::max(q, s);
  const int p = 1 + q + s;
  if (par.size() != p) stop("Length of `par` must be 1 + q + s.");

  NumericVector err2pad(n + h);
  NumericVector sigpad(n + h);
  NumericVector sigma2(n);
  NumericMatrix Dpad(n + h, p);

  for (int t = 0; t < n; ++t) err2pad[t + h] = R_finite(err2[t]) ? err2[t] : 0.0;

  for (int t = 0; t < n; ++t) {
    double v = par[0];
    for (int i = 1; i <= q; ++i) v += par[i] * err2pad[t + h - i];
    for (int j = 1; j <= s; ++j) v += par[q + j] * sigpad[t + h - j];
    v = cgd_safe_pos(v);
    sigpad[t + h] = v;
    sigma2[t] = v;
  }

  for (int t = 0; t < n; ++t) {
    Dpad(t + h, 0) = 1.0;
    for (int i = 1; i <= q; ++i) Dpad(t + h, i) = err2pad[t + h - i];
    for (int j = 1; j <= s; ++j) Dpad(t + h, q + j) = sigpad[t + h - j];

    for (int j = 1; j <= s; ++j) {
      const double beta = par[q + j];
      for (int k = 0; k < p; ++k) {
        Dpad(t + h, k) += beta * Dpad(t + h - j, k);
      }
    }
  }

  NumericVector score(p);
  NumericVector qdiag(p);
  int neff = 0;

  for (int t = h; t < n; ++t) {
    const double sig = cgd_safe_pos(sigma2[t]);
    const double sig_sq = sig * sig;
    const double e2 = R_finite(err2[t]) ? err2[t] : 0.0;
    const double factor = (1.0 / sig) - (e2 / sig_sq);
    ++neff;

    for (int k = 0; k < p; ++k) {
      const double dk = Dpad(t + h, k);
      score[k] += factor * dk;
      qdiag[k] += (dk * dk) / sig_sq;
    }
  }

  if (neff > 0) {
    for (int k = 0; k < p; ++k) {
      score[k] /= (double) neff;
      qdiag[k] /= (double) neff;
    }
  }

  return List::create(
    Named("score") = score,
    Named("qdiag") = qdiag,
    Named("sigma2") = sigma2,
    Named("n_eff") = neff
  );
}

// Mean Gaussian quasi-likelihood without the penalty term.
double cgdgarch_qll_cpp(NumericVector err2, NumericVector par, int q, int s) {
  const int n = err2.size();
  const int h = std::max(q, s);
  NumericVector sigma2 = cgdgarch_sigma2_cpp(err2, par, q, s);
  double out = 0.0;
  int neff = 0;

  for (int t = h; t < n; ++t) {
    const double sig = cgd_safe_pos(sigma2[t]);
    const double e2 = R_finite(err2[t]) ? err2[t] : 0.0;
    out += std::log(sig) + e2 / sig;
    ++neff;
  }

  if (neff == 0) return NA_REAL;
  return out / (double) neff;
}
