// Generated manually for cgdgarch. Do not edit by hand after running Rcpp::compileAttributes().
#include <Rcpp.h>
#include <R_ext/Rdynload.h>
using namespace Rcpp;

NumericVector cgdgarch_sigma2_cpp(NumericVector err2, NumericVector par, int q, int s);
List cgdgarch_score_diag_cpp(NumericVector err2, NumericVector par, int q, int s);
double cgdgarch_qll_cpp(NumericVector err2, NumericVector par, int q, int s);

RcppExport SEXP _cgdgarch_cgdgarch_sigma2_cpp(SEXP err2SEXP, SEXP parSEXP, SEXP qSEXP, SEXP sSEXP) {
BEGIN_RCPP
  return Rcpp::wrap(cgdgarch_sigma2_cpp(Rcpp::as<Rcpp::NumericVector>(err2SEXP), Rcpp::as<Rcpp::NumericVector>(parSEXP), Rcpp::as<int>(qSEXP), Rcpp::as<int>(sSEXP)));
END_RCPP
}

RcppExport SEXP _cgdgarch_cgdgarch_score_diag_cpp(SEXP err2SEXP, SEXP parSEXP, SEXP qSEXP, SEXP sSEXP) {
BEGIN_RCPP
  return Rcpp::wrap(cgdgarch_score_diag_cpp(Rcpp::as<Rcpp::NumericVector>(err2SEXP), Rcpp::as<Rcpp::NumericVector>(parSEXP), Rcpp::as<int>(qSEXP), Rcpp::as<int>(sSEXP)));
END_RCPP
}

RcppExport SEXP _cgdgarch_cgdgarch_qll_cpp(SEXP err2SEXP, SEXP parSEXP, SEXP qSEXP, SEXP sSEXP) {
BEGIN_RCPP
  return Rcpp::wrap(cgdgarch_qll_cpp(Rcpp::as<Rcpp::NumericVector>(err2SEXP), Rcpp::as<Rcpp::NumericVector>(parSEXP), Rcpp::as<int>(qSEXP), Rcpp::as<int>(sSEXP)));
END_RCPP
}

static const R_CallMethodDef CallEntries[] = {
  {"_cgdgarch_cgdgarch_sigma2_cpp", (DL_FUNC) &_cgdgarch_cgdgarch_sigma2_cpp, 4},
  {"_cgdgarch_cgdgarch_score_diag_cpp", (DL_FUNC) &_cgdgarch_cgdgarch_score_diag_cpp, 4},
  {"_cgdgarch_cgdgarch_qll_cpp", (DL_FUNC) &_cgdgarch_cgdgarch_qll_cpp, 4},
  {NULL, NULL, 0}
};

RcppExport void R_init_cgdgarch(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
